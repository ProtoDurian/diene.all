{{- define "k8s-monitoring.beyla.config" -}}
{{- $beyla := .Values }}
{{- if hasKey .Values "autoInstrumentation" }}
  {{- $beyla = .Values.autoInstrumentation.beyla }}
{{- end }}
{{- $valuesMap := .Values | toYaml | fromYaml }}
{{- $beylaMap := $beyla | toYaml | fromYaml }}
{{- $config := (dig "config" "data" dict $beylaMap) | deepCopy }}
{{- $clusterName := "" }}
{{- if hasKey $valuesMap "cluster" }}
  {{- $clusterName = (dig "cluster" "name" "" $valuesMap) }}
{{- else if hasKey $valuesMap "global" }}
  {{- $clusterName = (dig "global" "cluster" "name" "" $valuesMap) }}
{{- end }}
{{- /* Beyla config is plain YAML and cannot evaluate an Alloy expression like cluster.nameFrom, so cluster_name is
       only set when a literal cluster name is available. Otherwise the attribute is omitted and the cluster label is
       applied downstream by the destination. */}}
{{- $kubernetesAttrs := dict "enable" true }}
{{- if $clusterName }}
  {{- $_ := set $kubernetesAttrs "cluster_name" $clusterName }}
{{- end }}
{{- $attributes := dict "kubernetes" $kubernetesAttrs }}
{{- $targetPort := dig "service" "targetPort" (dig "config" "data" "prometheus_export" "port" 9090 $beylaMap) $beylaMap }}
{{- $internalMetrics := dict "prometheus" (dict "port" $targetPort) }}
{{- $prometheusExport := dict "port" $targetPort }}
{{- $overrides := dict "attributes" $attributes "internal_metrics" $internalMetrics "prometheus_export" $prometheusExport }}

{{- if and (eq (dig "preset" "" $beylaMap) "network") (not (hasKey $config "network")) }}
  {{- $overrides = merge $overrides (dict "network" (dict "enable" true)) }}
{{- end }}
{{- if eq (dig "preset" "" $beylaMap) "application" }}
  {{- $userDiscovery := dig "discovery" dict $config }}
  {{- $discoveryDefaults := dict }}
  {{- if and (not (hasKey $userDiscovery "instrument")) (not (hasKey $userDiscovery "services")) }}
    {{- $_ := set $discoveryDefaults "instrument" (list (dict "k8s_namespace" "*")) }}
  {{- end }}
  {{- if and (not (hasKey $userDiscovery "exclude_instrument")) (not (hasKey $userDiscovery "exclude_services")) }}
    {{- $_ := set $discoveryDefaults "exclude_instrument" (list (dict "exe_path" "{*alloy*,*otelcol*,*beyla*}")) }}
  {{- end }}
  {{- if $discoveryDefaults }}
    {{- $overrides = merge $overrides (dict "discovery" $discoveryDefaults) }}
  {{- end }}
{{- end }}
{{- if and (dig "applicationObservability" "enabled" false $valuesMap) (dig "deliverTracesToApplicationObservability" false $beylaMap) }}
  {{- $endpoint := "" }}
  {{- if dig "applicationObservability" "receivers" "otlp" "grpc" "enabled" false $valuesMap }}
    {{- $endpoint = include "features.applicationObservability.receiver.grpc" . | trim }}
  {{- else if dig "applicationObservability" "receivers" "otlp" "http" "enabled" false $valuesMap }}
    {{- $endpoint = include "features.applicationObservability.receiver.http" . | trim }}
  {{- end }}
  {{- if $endpoint }}
    {{- $overrides = merge $overrides (dict "otel_traces_export" (dict "endpoint" $endpoint)) }}
  {{- end }}
{{- end }}

{{- merge $overrides $config | toYaml }}
{{- end }}
