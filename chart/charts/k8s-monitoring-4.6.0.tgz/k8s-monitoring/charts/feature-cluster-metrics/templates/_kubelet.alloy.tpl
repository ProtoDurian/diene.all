{{ define "feature.clusterMetrics.kubelet.allowList" }}
{{- $allowList := list }}
{{ if .Values.kubelet.metricsTuning.useDefaultAllowList }}
{{- $allowList = concat $allowList (list "up" "scrape_samples_scraped") (.Files.Get "default-allow-lists/kubelet.yaml" | fromYamlArray) -}}
{{ end }}
{{ if .Values.kubelet.metricsTuning.includeMetrics }}
{{- $allowList = concat $allowList (list "up" "scrape_samples_scraped") .Values.kubelet.metricsTuning.includeMetrics -}}
{{ end }}
{{ $allowList | uniq | toYaml }}
{{ end }}

{{- define "feature.clusterMetrics.kubelet.alloy" }}
{{- if .Values.kubelet.enabled }}
{{- $metricAllowList := include "feature.clusterMetrics.kubelet.allowList" . | fromYamlArray }}
{{- $metricDenyList := .Values.kubelet.metricsTuning.excludeMetrics }}

// Kubelet
discovery.relabel "kubelet" {
  targets = discovery.relabel.nodes.output
{{- if eq .Values.kubelet.nodeAddressFormat "proxy" }}
  rule {
    target_label = "__address__"
    replacement  = "{{ .Values.global.kubernetesAPIService | default "kubernetes.default.svc.cluster.local:443" }}"
  }
  rule {
    source_labels = ["__meta_kubernetes_node_name"]
    regex         = "(.+)"
    replacement   = "/api/v1/nodes/${1}/proxy/metrics"
    target_label  = "__metrics_path__"
  }
{{- end }}
{{- if .Values.kubelet.extraDiscoveryRules }}
{{ .Values.kubelet.extraDiscoveryRules | indent 2 }}
{{- end }}
} // discovery.relabel "kubelet"

prometheus.scrape "kubelet" {
  targets  = discovery.relabel.kubelet.output
  job_name = {{ .Values.kubelet.jobLabel | quote }}
  scheme   = "https"
  scrape_interval = {{ .Values.kubelet.scrapeInterval | default .Values.global.scrapeInterval | quote }}
  scrape_timeout = {{ .Values.kubelet.scrapeTimeout | default .Values.global.scrapeTimeout | quote }}
  scrape_protocols = {{ include "helper.scrapeProtocols" . }}
  scrape_classic_histograms = {{ .Values.global.scrapeClassicHistograms }}
  scrape_native_histograms = {{ .Values.global.scrapeNativeHistograms }}
  convert_classic_histograms_to_nhcb = {{ .Values.global.convertClassicHistogramsToNhcb }}
  bearer_token_file = "/var/run/secrets/kubernetes.io/serviceaccount/token"

  tls_config {
    ca_file = "/var/run/secrets/kubernetes.io/serviceaccount/ca.crt"
    insecure_skip_verify = true
    server_name = "kubernetes"
  }

  clustering {
    enabled = true
  }

  forward_to = [prometheus.relabel.kubelet.receiver]
} // prometheus.scrape "kubelet"

prometheus.relabel "kubelet" {
  {{- include "helper.relabelCacheArguments" (dict "maxCacheSize" .Values.kubelet.maxCacheSize "cacheTTL" .Values.kubelet.cacheTTL "global" .Values.global) | nindent 2 }}

{{- if $metricAllowList }}
  rule {
    source_labels = ["__name__"]
    regex = {{ $metricAllowList | join "|" | quote }}
    action = "keep"
  }
{{- end }}
{{- if $metricDenyList }}
  rule {
    source_labels = ["__name__"]
    regex = {{ $metricDenyList | join "|" | quote }}
    action = "drop"
  }
{{- end }}
{{- if .Values.kubelet.extraMetricProcessingRules }}
  {{ .Values.kubelet.extraMetricProcessingRules | indent 2 }}
{{- end }}

  forward_to = argument.metrics_destinations.value
} // prometheus.relabel "kubelet"
{{- end }}
{{- end }}
