{{ define "helper.kubernetesName" }}
{{- . | lower | replace " " "-" | replace "_" "-" -}}
{{ end }}

{{ define "helper.alloy_name" }}
{{- . | lower | replace " " "_" | replace "-" "_" -}}
{{ end }}

{{- define "escape_label" -}}
{{ . | replace "-" "_" | replace "." "_" | replace "/" "_" }}
{{- end }}

{{- define "pod_label" -}}
{{ printf "__meta_kubernetes_pod_label_%s" (include "escape_label" .) }}
{{- end }}
{{- define "pod_annotation" -}}
{{ printf "__meta_kubernetes_pod_annotation_%s" (include "escape_label" .) }}
{{- end }}

{{- define "english_list" }}
{{- if eq (len .) 0 }}
{{- else if eq (len .) 1 }}
{{- index . 0 }}
{{- else if eq (len .) 2 }}
{{- index . 0 }} and {{ index . 1 }}
{{- else }}
{{- $last := index . (sub (len .) 1) }}
{{- $rest := slice . 0 (sub (len .) 1) }}
{{- join ", " $rest }}, and {{ $last }}
{{- end }}
{{- end }}

{{- define "feature.integrations.commonDiscoveryRules" }}
rule {
  source_labels = ["__meta_kubernetes_namespace"]
  target_label  = "namespace"
}

rule {
  source_labels = ["__meta_kubernetes_pod_name"]
  target_label  = "pod"
}

rule {
  source_labels = ["__meta_kubernetes_pod_container_name"]
  target_label  = "container"
}

// set the workload to the controller kind and name
rule {
  action = "lowercase"
  source_labels = ["__meta_kubernetes_pod_controller_kind"]
  target_label  = "workload_type"
}

rule {
  source_labels = ["__meta_kubernetes_pod_controller_name"]
  target_label  = "workload"
}

// remove the hash from the ReplicaSet
rule {
  source_labels = [
    "workload_type",
    "workload",
  ]
  separator = "/"
  regex = "replicaset/(.+)-.+$"
  target_label  = "workload"
}

// set the app name if specified as metadata labels "app:" or "app.kubernetes.io/name:" or "k8s-app:"
rule {
  action = "replace"
  source_labels = [
    "__meta_kubernetes_pod_label_app_kubernetes_io_name",
    "__meta_kubernetes_pod_label_k8s_app",
    "__meta_kubernetes_pod_label_app",
  ]
  separator = ";"
  regex = "^(?:;*)?([^;]+).*$"
  replacement = "$1"
  target_label = "app"
}

// set the component if specified as metadata labels "component:" or "app.kubernetes.io/component:" or "k8s-component:"
rule {
  action = "replace"
  source_labels = [
    "__meta_kubernetes_pod_label_app_kubernetes_io_component",
    "__meta_kubernetes_pod_label_k8s_component",
    "__meta_kubernetes_pod_label_component",
  ]
  regex = "^(?:;*)?([^;]+).*$"
  replacement = "$1"
  target_label = "component"
}

// set a source label
rule {
  action = "replace"
  replacement = "kubernetes"
  target_label = "source"
}
{{ include "feature.integrations.nodeDiscoveryRules" . }}
{{- end }}

{{- define "feature.integrations.attachNodeMetadata" }}
{{- $attachMetadata := false -}}
{{- $attachMetadata = or $attachMetadata .Values.nodeLabels.nodePool -}}
{{- $attachMetadata = or $attachMetadata .Values.nodeLabels.region -}}
{{- $attachMetadata = or $attachMetadata .Values.nodeLabels.availabilityZone -}}
{{- $attachMetadata = or $attachMetadata .Values.nodeLabels.nodeRole -}}
{{- $attachMetadata = or $attachMetadata .Values.nodeLabels.nodeOS -}}
{{- $attachMetadata = or $attachMetadata .Values.nodeLabels.nodeArchitecture -}}
{{- $attachMetadata = or $attachMetadata .Values.nodeLabels.instanceType -}}
{{- if eq $attachMetadata true }}
attach_metadata {
  node = true
}
{{- end }}
{{- end }}

{{- define "helper.namespace" -}}
{{- .Values.global.namespaceOverride | default .Release.Namespace -}}
{{- end -}}

{{- define "helper.scrapeProtocols" -}}
{{- $protocols := .Values.global.scrapeProtocols -}}
{{- if and .Values.global.scrapeNativeHistograms (not (has "PrometheusProto" $protocols)) -}}
{{- $protocols = prepend $protocols "PrometheusProto" -}}
{{- end -}}
{{ $protocols | toJson }}
{{- end -}}

{{- define "helper.relabelCacheArguments" -}}
{{- $settings := . -}}
{{- if not (or .maxCacheSize .cacheTTL) -}}
  {{- $settings = .global -}}
{{- end -}}
{{- if $settings.cacheTTL -}}
max_cache_size = 0
cache_ttl = {{ $settings.cacheTTL | quote }}
{{- else -}}
max_cache_size = {{ $settings.maxCacheSize | int }}
{{- end -}}
{{- end -}}

{{- define "helper.validateRelabelCacheSettings" -}}
{{- $sources := dict .path .values -}}
{{- range $key, $value := .values -}}
  {{- if and (kindIs "map" $value) (ne $key "global") -}}
    {{- $_ := set $sources (printf "%s.%s" $.path $key) $value -}}
  {{- end -}}
{{- end -}}
{{- range $path, $source := $sources -}}
  {{- if and ($source.maxCacheSize | default 0 | int) $source.cacheTTL -}}
    {{- $msg := list "" (printf "%s.maxCacheSize and %s.cacheTTL are mutually exclusive." $path $path) -}}
    {{- $msg = append $msg "Please set only one of them." -}}
    {{- fail (join "\n" $msg) -}}
  {{- end -}}
{{- end -}}
{{- end -}}
