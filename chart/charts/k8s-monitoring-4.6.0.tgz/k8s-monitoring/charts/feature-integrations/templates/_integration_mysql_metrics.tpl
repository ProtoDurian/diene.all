{{/* Inputs: . (Values) */}}
{{- define "integrations.mysql.type.metrics" }}
{{- $defaultValues := "integrations/mysql-values.yaml" | .Files.Get | fromYaml }}
{{- $metricsEnabled := false }}
{{- range $instance := .Values.mysql.instances }}
  {{- $metricsEnabled = or $metricsEnabled (dig "metrics" "enabled" true $instance) }}
{{- end }}
{{- $metricsEnabled -}}
{{- end }}

{{/* Inputs: . (Values), instance (this MySQL instance) */}}
{{- define "integrations.mysql.datasource" }}
  {{- if .exporter.dataSourceNameFrom }}
data_source_name = {{ .exporter.dataSourceNameFrom }}
  {{- else if .exporter.dataSourceName }}
data_source_name = {{ .exporter.dataSourceName | quote }}
  {{- else }}
    {{- $dataSourceParamList := list }}
    {{- if .exporter.dataSource.allowFallbackToPlaintext }}
      {{- $dataSourceParamList = append $dataSourceParamList (printf "allowFallbackToPlaintext=%t" .exporter.dataSource.allowFallbackToPlaintext) }}
    {{- end }}
    {{- if .exporter.dataSource.tls }}
      {{- $dataSourceParamList = append $dataSourceParamList (printf "tls=%s" .exporter.dataSource.tls) }}
    {{- end }}
    {{- $dataSourceParams := "" }}
    {{- if $dataSourceParamList }}
      {{- $dataSourceParams = printf "?%s" ($dataSourceParamList | join "&") }}
    {{- end }}
    {{- if eq (include "secrets.usesSecret" (dict "object" . "key" "exporter.dataSource.auth.username")) "true" }}
      {{- if eq (include "secrets.usesSecret" (dict "object" . "key" "exporter.dataSource.auth.password")) "true" }}
data_source_name = string.format("%s:%s@{{ .exporter.dataSource.protocol }}(%s:%d)/{{ $dataSourceParams }}",
  {{ include "secrets.read" (dict "object" . "key" "exporter.dataSource.auth.username" "nonsensitive" true) }},
  {{ include "secrets.read" (dict "object" . "key" "exporter.dataSource.auth.password" "nonsensitive" true) }},
  {{ .exporter.dataSource.host | quote }},
  {{ .exporter.dataSource.port | int }},
)
      {{- else }}
data_source_name = string.format("%s@{{ .exporter.dataSource.protocol }}(%s:%d)/{{ $dataSourceParams }}",
  {{ include "secrets.read" (dict "object" . "key" "exporter.dataSource.auth.username" "nonsensitive" true) }},
  {{ .exporter.dataSource.host | quote }},
  {{ .exporter.dataSource.port | int }},
)
      {{- end }}
    {{- else if .exporter.dataSource.protocol }}
data_source_name = string.format("{{ .exporter.dataSource.protocol }}(%s:%d)/", {{ .exporter.dataSource.host | quote }}, {{ .exporter.dataSource.port | int }})
    {{- else }}
data_source_name = string.format("%s:%d/", {{ .exporter.dataSource.host | quote }}, {{ .exporter.dataSource.port | int }})
    {{- end }}
  {{- end }}
{{- end }}

{{- define "integrations.mysql.module.metrics" }}
declare "mysql_integration" {
  argument "metrics_destinations" {
    comment = "Must be a list of metric destinations where collected metrics should be forwarded to"
  }
  {{- if eq (include "integrations.mysql.type.logOutput" .) "true" }}
  argument "logs_destinations" {
    comment = "Must be a list of log destinations where collected logs should be forwarded to"
  }
  {{- end }}
  {{- range $instance := $.Values.mysql.instances }}
    {{- include "integrations.mysql.include.metrics" (deepCopy $ | merge (dict "instance" $instance)) | nindent 2 }}
  {{- end }}
}
{{- end }}

{{/* Inputs: . (Values), instance (this MySQL instance) */}}
{{- define "integrations.mysql.include.metrics" }}
{{- $defaultValues := "integrations/mysql-values.yaml" | .Files.Get | fromYaml }}
{{- $userSetJobLabel := hasKey $.instance "jobLabel" }}
{{- with mergeOverwrite $defaultValues .instance (dict "type" "integration.mysql") }}
{{- $alloyName := include "helper.alloy_name" .name }}
{{- $dbRelabelName := printf "database_observability_mysql_%s" $alloyName }}
{{- $jobLabel := .jobLabel }}
{{- if and .databaseObservability.enabled (not $userSetJobLabel) }}
  {{- $jobLabel = "integrations/db-o11y" }}
{{- end }}
{{- $hasTuning := or .metrics.tuning.includeMetrics .metrics.tuning.excludeMetrics .metrics.extraMetricProcessingRules }}
{{- $emitPromRelabel := or (not .databaseObservability.enabled) $hasTuning }}
{{- if eq (include "secrets.usesKubernetesSecret" .) "true" }}
  {{- include "secret.alloy" (deepCopy $ | merge (dict "object" .)) | indent 0 }}
{{- end }}
{{- if .metrics.enabled }}
prometheus.exporter.mysql {{ include "helper.alloy_name" .name | quote }} {
  {{- include "integrations.mysql.datasource" . | indent 2 }}
  {{- $enabledCollectors := list }}
  {{- if kindIs "slice" .exporter.collectors }}
    {{- $enabledCollectors = .exporter.collectors }}
  {{- else }}
    {{- if .exporter.collectors.heartbeat.enabled }}
      {{- $enabledCollectors = append $enabledCollectors "heartbeat" }}
      {{- if or .exporter.collectors.heartbeat.database .exporter.collectors.heartbeat.table }}
  heartbeat {
      {{- if .exporter.collectors.heartbeat.database }}
    database = {{ .exporter.collectors.heartbeat.database | quote }}
      {{- end }}
      {{- if .exporter.collectors.heartbeat.table }}
    table = {{ .exporter.collectors.heartbeat.table | quote }}
      {{- end }}
  }
      {{- end }}
    {{- end }}
    {{- if .exporter.collectors.mysqlUser.enabled }}
      {{- $enabledCollectors = append $enabledCollectors "mysql.user" }}
      {{- if .exporter.collectors.mysqlUser.privileges }}
  mysql.user {
    privileges = true
  }
      {{- end }}
    {{- end }}
    {{- if .exporter.collectors.perfSchemaEventsStatements.enabled }}
      {{- $enabledCollectors = append $enabledCollectors "perf_schema.eventsstatements" }}
      {{- $opts := .exporter.collectors.perfSchemaEventsStatements }}
      {{- if or $opts.limit $opts.textLimit $opts.timeLimit .databaseObservability.enabled }}
  perf_schema.eventsstatements {
        {{- if $opts.limit }}
    limit = {{ $opts.limit | int }}
        {{- end }}
        {{- if not (kindIs "invalid" $opts.textLimit) }}
    text_limit = {{ $opts.textLimit | int }}
        {{- else if .databaseObservability.enabled }}
    text_limit = 0
        {{- end }}
        {{- if $opts.timeLimit }}
    time_limit = {{ $opts.timeLimit | int }}
        {{- end }}
  }
      {{- end }}
    {{- end }}
  {{- end }}
  enable_collectors = {{ $enabledCollectors | toJson }}
}
{{- end }}
{{- if .databaseObservability.enabled }}

database_observability.mysql {{ include "helper.alloy_name" .name | quote }} {
  targets = prometheus.exporter.mysql.{{ include "helper.alloy_name" .name }}.targets
  {{- include "integrations.mysql.datasource" . | indent 2 }}
  allow_update_performance_schema_settings = {{ .databaseObservability.allowUpdatePerformanceSchemaSettings }}
  {{- if .databaseObservability.excludeSchemas }}
  exclude_schemas = {{ .databaseObservability.excludeSchemas | toJson }}
  {{- end }}

  {{- with .databaseObservability.cloudProvider }}
  {{- $hasAws := and .aws .aws.arn }}
  {{- $hasAzure := and .azure .azure.subscriptionId .azure.resourceGroup }}
  {{- $hasGcp := and .gcp .gcp.connectionName }}
  {{- if or $hasAws $hasAzure $hasGcp }}
  cloud_provider {
    {{- if $hasAws }}
    aws {
      arn = {{ .aws.arn | quote }}
    }
    {{- end }}
    {{- if $hasAzure }}
    azure {
      subscription_id = {{ .azure.subscriptionId | quote }}
      resource_group = {{ .azure.resourceGroup | quote }}
      {{- if .azure.serverName }}
      server_name = {{ .azure.serverName | quote }}
      {{- end }}
    }
    {{- end }}
    {{- if $hasGcp }}
    gcp {
      connection_name = {{ .gcp.connectionName | quote }}
    }
    {{- end }}
  }
  {{- end }}
  {{- end }}

  {{- $enabledCollectors := list }}
  {{- $disabledCollectors := list }}
  {{- if .databaseObservability.collectors.explainPlans.enabled }}
    {{- $enabledCollectors = append $enabledCollectors "explain_plans" }}
    {{- with .databaseObservability.collectors.explainPlans }}
  explain_plans {
    collect_interval = {{ .collectInterval | quote }}
    initial_lookback = {{ .initialLookback | quote }}
    per_collect_ratio = {{ .perCollectRatio | quote }}
  }
    {{- end }}
  {{- else }}
    {{- $disabledCollectors = append $disabledCollectors "explain_plans" }}
  {{- end }}
  {{- if .databaseObservability.collectors.locks.enabled }}
    {{- $enabledCollectors = append $enabledCollectors "locks" }}
    {{- with .databaseObservability.collectors.locks }}
  locks {
    collect_interval = {{ .collectInterval | quote }}
    threshold = {{ .threshold | quote }}
  }
    {{- end }}
  {{- else }}
    {{- $disabledCollectors = append $disabledCollectors "locks" }}
  {{- end }}
  {{- if .databaseObservability.collectors.queryDetails.enabled }}
    {{- $enabledCollectors = append $enabledCollectors "query_details" }}
    {{- with .databaseObservability.collectors.queryDetails }}
  query_details {
    collect_interval = {{ .collectInterval | quote }}
    {{- if .statementsLimit }}
    statements_limit = {{ .statementsLimit | int }}
    {{- end }}
  }
    {{- end }}
  {{- else }}
    {{- $disabledCollectors = append $disabledCollectors "query_details" }}
  {{- end }}
  {{- if .databaseObservability.collectors.querySamples.enabled }}
    {{- $enabledCollectors = append $enabledCollectors "query_samples" }}
    {{- with .databaseObservability.collectors.querySamples }}
  query_samples {
    collect_interval = {{ .collectInterval | quote }}
    disable_query_redaction = {{ .disableQueryRedaction }}
    auto_enable_setup_consumers = {{ .autoEnableSetupConsumers }}
    setup_consumers_check_interval = {{ .setupConsumersCheckInterval | quote }}
    sample_min_duration = {{ .sampleMinDuration | quote }}
    wait_event_min_duration = {{ .waitEventMinDuration | quote }}
  }
    {{- end }}
  {{- else }}
    {{- $disabledCollectors = append $disabledCollectors "query_samples" }}
  {{- end }}
  {{- if .databaseObservability.collectors.schemaDetails.enabled }}
    {{- $enabledCollectors = append $enabledCollectors "schema_details" }}
    {{- with .databaseObservability.collectors.schemaDetails }}
  schema_details {
    collect_interval = {{ .collectInterval | quote }}
  }
    {{- end }}
  {{- else }}
    {{- $disabledCollectors = append $disabledCollectors "schema_details" }}
  {{- end }}
  {{- if .databaseObservability.collectors.setupConsumers.enabled }}
    {{- $enabledCollectors = append $enabledCollectors "setup_consumers" }}
    {{- with .databaseObservability.collectors.setupConsumers }}
  setup_consumers {
    collect_interval = {{ .collectInterval | quote }}
  }
    {{- end }}
  {{- else }}
    {{- $disabledCollectors = append $disabledCollectors "setup_consumers" }}
  {{- end }}
  {{- if .databaseObservability.collectors.setupActors.enabled }}
    {{- $enabledCollectors = append $enabledCollectors "setup_actors" }}
    {{- with .databaseObservability.collectors.setupActors }}
  setup_actors {
    auto_update_setup_actors = {{ .autoUpdateSetupActors }}
    collect_interval = {{ .collectInterval | quote }}
  }
    {{- end }}
  {{- else }}
    {{- $disabledCollectors = append $disabledCollectors "setup_actors" }}
  {{- end }}
  enable_collectors = {{ $enabledCollectors | toJson }}
  {{- if $disabledCollectors }}
  disable_collectors = {{ $disabledCollectors | toJson }}
  {{- end }}

  forward_to = [loki.relabel.{{ $dbRelabelName }}.receiver]
}

loki.relabel {{ $dbRelabelName | quote }} {
  forward_to = argument.logs_destinations.value
  rule {
    target_label = "job"
    replacement = {{ $jobLabel | quote }}
  }
  rule {
    source_labels = ["instance"]
    target_label = "dsn"
  }
  rule {
    target_label = "instance"
    replacement = {{ .name | quote }}
  }
  {{- range $label, $value := .databaseObservability.labels }}
  rule {
    target_label = {{ $label | quote }}
    replacement = {{ $value | quote }}
  }
  {{- end }}
}

discovery.relabel {{ $dbRelabelName | quote }} {
  targets = database_observability.mysql.{{ $alloyName }}.targets
  rule {
    target_label = "job"
    replacement = {{ $jobLabel | quote }}
  }
  rule {
    source_labels = ["instance"]
    target_label = "dsn"
  }
  rule {
    target_label = "instance"
    replacement = {{ .name | quote }}
  }
  {{- range $label, $value := .databaseObservability.labels }}
  rule {
    target_label = {{ $label | quote }}
    replacement = {{ $value | quote }}
  }
  {{- end }}
}
{{- end }}

{{- if .metrics.enabled }}
prometheus.scrape {{ $alloyName | quote }} {
  {{- if .databaseObservability.enabled }}
  targets = discovery.relabel.{{ $dbRelabelName }}.output
  {{- else }}
  targets = prometheus.exporter.mysql.{{ $alloyName }}.targets
  {{- end }}
  clustering {
    enabled = true
  }

  scrape_interval = {{ .metrics.scrapeInterval | default $.Values.global.scrapeInterval | quote }}
  scrape_timeout = {{ .metrics.scrapeTimeout | default $.Values.global.scrapeTimeout | quote }}
  scrape_protocols = {{ include "helper.scrapeProtocols" $ }}
  scrape_classic_histograms = {{ $.Values.global.scrapeClassicHistograms }}
  scrape_native_histograms = {{ $.Values.global.scrapeNativeHistograms }}
  {{- if $emitPromRelabel }}
  forward_to = [prometheus.relabel.{{ $alloyName }}.receiver]
  {{- else }}
  forward_to = argument.metrics_destinations.value
  {{- end }}
}

{{- if $emitPromRelabel }}

prometheus.relabel {{ $alloyName | quote }} {
  {{- include "helper.relabelCacheArguments" (dict "maxCacheSize" .metrics.maxCacheSize "cacheTTL" .metrics.cacheTTL "global" $.Values.global) | nindent 2 }}
{{- if not .databaseObservability.enabled }}
  rule {
    target_label = "instance"
    replacement = {{ .name | quote }}
  }
  rule {
    target_label = "job"
    replacement = {{ $jobLabel | quote }}
  }
{{- end }}
{{- if .metrics.tuning.includeMetrics }}
  rule {
    source_labels = ["__name__"]
    regex = "up|scrape_samples_scraped|{{ .metrics.tuning.includeMetrics | join "|" }}"
    action = "keep"
  }
{{- end }}
{{- if .metrics.tuning.excludeMetrics }}
  rule {
    source_labels = ["__name__"]
    regex = {{ .metrics.tuning.excludeMetrics | join "|" | quote }}
    action = "drop"
  }
{{- end }}
{{- if .metrics.extraMetricProcessingRules }}
{{ .metrics.extraMetricProcessingRules | indent 2 }}
{{- end }}
  forward_to = argument.metrics_destinations.value
}
{{- end }}
{{- end }}
{{- end }}
{{- end }}
