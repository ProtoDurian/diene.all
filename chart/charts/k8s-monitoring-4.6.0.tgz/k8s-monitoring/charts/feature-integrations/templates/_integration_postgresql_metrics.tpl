{{/* Inputs: . (Values) */}}
{{- define "integrations.postgresql.type.metrics" }}
{{- $defaultValues := "integrations/postgresql-values.yaml" | .Files.Get | fromYaml }}
{{- $metricsEnabled := false }}
{{- range $instance := .Values.postgresql.instances }}
  {{- $metricsEnabled = or $metricsEnabled (dig "metrics" "enabled" true $instance) }}
{{- end }}
{{- $metricsEnabled -}}
{{- end }}

{{/* Inputs: . (Values), instance (this PostgreSQL instance) */}}
{{- define "integrations.postgresql.datasource" }}
  {{- if .exporter.dataSourceNameFrom }}
{{ .exporter.dataSourceNameFrom }}
  {{- else if .exporter.dataSourceName }}
{{ .exporter.dataSourceName | quote }}
  {{- else }}
    {{- $dataSourceParamList := list }}
    {{- if .exporter.dataSource.sslmode }}
      {{- $dataSourceParamList = append $dataSourceParamList (printf "sslmode=%s" .exporter.dataSource.sslmode) }}
    {{- end }}
    {{- $dataSourceParams := "" }}
    {{- if $dataSourceParamList }}
      {{- $dataSourceParams = printf "?%s" ($dataSourceParamList | join "&") }}
    {{- end }}
    {{- if eq (include "secrets.usesSecret" (dict "object" . "key" "exporter.dataSource.auth.username")) "true" }}
      {{- if eq (include "secrets.usesSecret" (dict "object" . "key" "exporter.dataSource.auth.password")) "true" }}
string.format("{{ .exporter.dataSource.protocol }}://%s:%s@%s:%d/{{ .exporter.dataSource.database }}{{ $dataSourceParams }}",
  encoding.url_encode({{ include "secrets.read" (dict "object" . "key" "exporter.dataSource.auth.username" "nonsensitive" true) }}),
  encoding.url_encode({{ include "secrets.read" (dict "object" . "key" "exporter.dataSource.auth.password" "nonsensitive" true) }}),
  {{ .exporter.dataSource.host | quote }},
  {{ .exporter.dataSource.port | int }},
)
      {{- else }}
string.format("{{ .exporter.dataSource.protocol }}://%s@%s:%d/{{ .exporter.dataSource.database }}{{ $dataSourceParams }}",
  encoding.url_encode({{ include "secrets.read" (dict "object" . "key" "exporter.dataSource.auth.username" "nonsensitive" true) }}),
  {{ .exporter.dataSource.host | quote }},
  {{ .exporter.dataSource.port | int }},
)
      {{- end }}
    {{- else if .exporter.dataSource.protocol }}
string.format("{{ .exporter.dataSource.protocol }}://%s:%d/{{ .exporter.dataSource.database }}", {{ .exporter.dataSource.host | quote }}, {{ .exporter.dataSource.port | int }})
    {{- else }}
string.format("%s:%d/{{ .exporter.dataSource.database }}", {{ .exporter.dataSource.host | quote }}, {{ .exporter.dataSource.port | int }})
    {{- end }}
  {{- end }}
{{- end }}

{{- define "integrations.postgresql.module.metrics" }}
declare "postgresql_integration" {
  argument "metrics_destinations" {
    comment = "Must be a list of metric destinations where collected metrics should be forwarded to"
  }
  {{- if eq (include "integrations.postgresql.type.logOutput" .) "true" }}
  argument "logs_destinations" {
    comment = "Must be a list of log destinations where collected logs should be forwarded to"
  }
  {{- end }}
  {{- range $instance := $.Values.postgresql.instances }}
    {{- include "integrations.postgresql.include.metrics" (deepCopy $ | merge (dict "instance" $instance)) | nindent 2 }}
  {{- end }}
}
{{- end }}

{{- define "integrations.postgresql.collectors" }}
  {{- $enabledCollectors := list }}
  {{- range $collector, $settings := .exporter.collectors }}
    {{- if $settings.enabled }}
      {{- if eq $collector "buffercacheSummary"           }}{{ $enabledCollectors = append $enabledCollectors "buffercache_summary" }}
      {{- else if eq $collector "databaseWraparound"      }}{{ $enabledCollectors = append $enabledCollectors "database_wraparound" }}
      {{- else if eq $collector "longRunningTransactions" }}{{ $enabledCollectors = append $enabledCollectors "long_running_transactions" }}
      {{- else if eq $collector "postmaster"              }}{{ $enabledCollectors = append $enabledCollectors "postmaster" }}
      {{- else if eq $collector "processIdle"             }}{{ $enabledCollectors = append $enabledCollectors "process_idle" }}
      {{- else if eq $collector "replicationSlot"         }}{{ $enabledCollectors = append $enabledCollectors "replication_slot" }}
      {{- else if eq $collector "statActivityAutovacuum"  }}{{ $enabledCollectors = append $enabledCollectors "stat_activity_autovacuum" }}
      {{- else if eq $collector "statBGWriter"            }}{{ $enabledCollectors = append $enabledCollectors "stat_bgwriter" }}
      {{- else if eq $collector "statCheckpointer"        }}{{ $enabledCollectors = append $enabledCollectors "stat_checkpointer" }}
      {{- else if eq $collector "statDatabase"            }}{{ $enabledCollectors = append $enabledCollectors "stat_database" }}
      {{- else if eq $collector "statProgressVacuum"      }}{{ $enabledCollectors = append $enabledCollectors "stat_progress_vacuum" }}
      {{- else if eq $collector "statStatements"          }}{{ $enabledCollectors = append $enabledCollectors "stat_statements" }}
      {{- else if eq $collector "statUserTables"          }}{{ $enabledCollectors = append $enabledCollectors "stat_user_tables" }}
      {{- else if eq $collector "statWALReceiver"         }}{{ $enabledCollectors = append $enabledCollectors "stat_wal_receiver" }}
      {{- else if eq $collector "statioUserIndexes"       }}{{ $enabledCollectors = append $enabledCollectors "statio_user_indexes" }}
      {{- else if eq $collector "statioUserTables"        }}{{ $enabledCollectors = append $enabledCollectors "statio_user_tables" }}
      {{- else if eq $collector "xlogLocation"            }}{{ $enabledCollectors = append $enabledCollectors "xlog_location" }}
      {{- else }}{{ $enabledCollectors = append $enabledCollectors $collector }}
      {{- end }}
    {{- end }}
  {{- end }}
  {{- $enabledCollectors | toJson }}
{{- end }}

{{/* Inputs: . (Values), instance (this PostgreSQL instance) */}}
{{- define "integrations.postgresql.include.metrics" }}
{{- $defaultValues := "integrations/postgresql-values.yaml" | .Files.Get | fromYaml }}
{{- $userSetJobLabel := hasKey $.instance "jobLabel" }}
{{- with mergeOverwrite $defaultValues .instance (dict "type" "integration.postgresql") }}
{{- $alloyName := include "helper.alloy_name" .name }}
{{- $dbRelabelName := printf "database_observability_postgres_%s" $alloyName }}
{{- $jobLabel := .jobLabel }}
{{- if and .databaseObservability.enabled (not $userSetJobLabel) }}
  {{- $jobLabel = "integrations/db-o11y" }}
{{- end }}
{{- $hasTuning := or .metrics.tuning.includeMetrics .metrics.tuning.excludeMetrics .metrics.extraMetricProcessingRules }}
{{- $emitPromRelabel := or (not .databaseObservability.enabled) $hasTuning }}
{{- if eq (include "secrets.usesKubernetesSecret" .) "true" }}
  {{- include "secret.alloy" (deepCopy $ | merge (dict "object" .)) | indent 0 }}
{{- end }}
{{- if .metrics.enabled }}
prometheus.exporter.postgres {{ include "helper.alloy_name" .name | quote }} {
  data_source_names = [{{- include "integrations.postgresql.datasource" . | indent 2 | trim }}]
  enabled_collectors = {{ include "integrations.postgresql.collectors" . }}
  {{- if .exporter.autoDiscovery.enabled }}
  autodiscovery {
    enabled = {{ .exporter.autoDiscovery.enabled }}
    {{- if .exporter.autoDiscovery.databaseAllowList }}
    database_allowlist = {{ .exporter.autoDiscovery.databaseAllowList | toJson }}
    {{- end }}
    {{- if .exporter.autoDiscovery.databaseDenyList }}
    database_denylist = {{ .exporter.autoDiscovery.databaseDenyList | toJson }}
    {{- end }}
  }
  {{- end }}
  {{- if .exporter.collectors.statStatements.enabled }}
    {{- if or .exporter.collectors.statStatements.includeQuery .exporter.collectors.statStatements.queryLength .exporter.collectors.statStatements.limit .exporter.collectors.statStatements.excludeDatabases .exporter.collectors.statStatements.excludeUsers }}
  stat_statements {
    include_query = {{ .exporter.collectors.statStatements.includeQuery }}
    {{- if .exporter.collectors.statStatements.queryLength }}
    query_length = {{ .exporter.collectors.statStatements.queryLength }}
    {{- end }}
    {{- if .exporter.collectors.statStatements.limit }}
    limit = {{ .exporter.collectors.statStatements.limit }}
    {{- end }}
    {{- if .exporter.collectors.statStatements.excludeDatabases }}
    exclude_databases = {{ .exporter.collectors.statStatements.excludeDatabases | toJson }}
    {{- end }}
    {{- if .exporter.collectors.statStatements.excludeUsers }}
    exclude_users = {{ .exporter.collectors.statStatements.excludeUsers | toJson }}
    {{- end }}
  }
    {{- end }}
  {{- end }}
  {{- if .exporter.customQueriesConfigPath }}
  custom_queries_config_path = {{ .exporter.customQueriesConfigPath | quote }}
  {{- end }}
  disable_default_metrics = {{ .exporter.disableDefaultMetrics }}
  disable_settings_metrics = {{ .exporter.disableSettingsMetrics }}
}
{{- end }}
{{- if .databaseObservability.enabled }}

database_observability.postgres {{ include "helper.alloy_name" .name | quote }} {
  targets = prometheus.exporter.postgres.{{ include "helper.alloy_name" .name }}.targets
  data_source_name = {{ include "integrations.postgresql.datasource" . | indent 2 | trim }}

  {{- with .databaseObservability.cloudProvider }}
  {{- $hasAws := and .aws .aws.arn }}
  {{- $hasAzure := and .azure .azure.subscriptionId .azure.resourceGroup }}
  {{- $hasGcp := and .gcp .gcp.connectionName }}
  {{- if or $hasAws $hasAzure $hasGcp }}
  cloud_provider {
    {{- if $hasAws }}
    aws {
      arn = {{ .aws.arn | quote }}
    }
    {{- end }}
    {{- if $hasAzure }}
    azure {
      subscription_id = {{ .azure.subscriptionId | quote }}
      resource_group = {{ .azure.resourceGroup | quote }}
      {{- if .azure.serverName }}
      server_name = {{ .azure.serverName | quote }}
      {{- end }}
    }
    {{- end }}
    {{- if $hasGcp }}
    gcp {
      connection_name = {{ .gcp.connectionName | quote }}
    }
    {{- end }}
  }
  {{- end }}
  {{- end }}
  {{- if .databaseObservability.excludeDatabases }}
  exclude_databases = {{ .databaseObservability.excludeDatabases | toJson }}
  {{- end }}
  {{- if .databaseObservability.excludeUsers }}
  exclude_users = {{ .databaseObservability.excludeUsers | toJson }}
  {{- end }}
  exclude_current_user = {{ .databaseObservability.excludeCurrentUser }}

  {{- $enabledCollectors := list }}
  {{- $disabledCollectors := list }}
  {{- if .databaseObservability.collectors.explainPlans.enabled }}
    {{- $enabledCollectors = append $enabledCollectors "explain_plans" }}
    {{- with .databaseObservability.collectors.explainPlans }}
  explain_plans {
    collect_interval = {{ .collectInterval | quote }}
    per_collect_ratio = {{ .perCollectRatio | quote }}
  }
    {{- end }}
  {{- else }}
    {{- $disabledCollectors = append $disabledCollectors "explain_plans" }}
  {{- end }}
  {{- if .databaseObservability.collectors.queryDetails.enabled }}
    {{- $enabledCollectors = append $enabledCollectors "query_details" }}
    {{- with .databaseObservability.collectors.queryDetails }}
  query_details {
    collect_interval = {{ .collectInterval | quote }}
    {{- if .statementsLimit }}
    statements_limit = {{ .statementsLimit | int }}
    {{- end }}
  }
    {{- end }}
  {{- else }}
    {{- $disabledCollectors = append $disabledCollectors "query_details" }}
  {{- end }}
  {{- if .databaseObservability.collectors.querySamples.enabled }}
    {{- $enabledCollectors = append $enabledCollectors "query_samples" }}
    {{- with .databaseObservability.collectors.querySamples }}
  query_samples {
    collect_interval = {{ .collectInterval | quote }}
    disable_query_redaction = {{ .disableQueryRedaction }}
    {{- if not (kindIs "invalid" .excludeCurrentUser) }}
    exclude_current_user = {{ .excludeCurrentUser }}
    {{- end }}
  }
    {{- end }}
  {{- else }}
    {{- $disabledCollectors = append $disabledCollectors "query_samples" }}
  {{- end }}
  {{- if .databaseObservability.collectors.schemaDetails.enabled }}
    {{- $enabledCollectors = append $enabledCollectors "schema_details" }}
    {{- with .databaseObservability.collectors.schemaDetails }}
  schema_details {
    collect_interval = {{ .collectInterval | quote }}
  }
    {{- end }}
  {{- else }}
    {{- $disabledCollectors = append $disabledCollectors "schema_details" }}
  {{- end }}
  enable_collectors = {{ $enabledCollectors | toJson }}
  {{- if $disabledCollectors }}
  disable_collectors = {{ $disabledCollectors | toJson }}
  {{- end }}

  forward_to = [loki.relabel.{{ $dbRelabelName }}.receiver]
}

loki.relabel {{ $dbRelabelName | quote }} {
  forward_to = argument.logs_destinations.value
  rule {
    target_label = "job"
    replacement = {{ $jobLabel | quote }}
  }
  rule {
    source_labels = ["instance"]
    target_label = "dsn"
  }
  rule {
    target_label = "instance"
    replacement = {{ .name | quote }}
  }
  {{- range $label, $value := .databaseObservability.labels }}
  rule {
    target_label = {{ $label | quote }}
    replacement = {{ $value | quote }}
  }
  {{- end }}
}

discovery.relabel {{ $dbRelabelName | quote }} {
  targets = database_observability.postgres.{{ $alloyName }}.targets
  rule {
    target_label = "job"
    replacement = {{ $jobLabel | quote }}
  }
  rule {
    source_labels = ["instance"]
    target_label = "dsn"
  }
  rule {
    target_label = "instance"
    replacement = {{ .name | quote }}
  }
  {{- range $label, $value := .databaseObservability.labels }}
  rule {
    target_label = {{ $label | quote }}
    replacement = {{ $value | quote }}
  }
  {{- end }}
}
{{- end }}

{{- if .metrics.enabled }}
prometheus.scrape {{ $alloyName | quote }} {
  {{- if .databaseObservability.enabled }}
  targets = discovery.relabel.{{ $dbRelabelName }}.output
  {{- else }}
  targets = prometheus.exporter.postgres.{{ $alloyName }}.targets
  {{- end }}
  clustering {
    enabled = true
  }

  scrape_interval = {{ .metrics.scrapeInterval | default $.Values.global.scrapeInterval | quote }}
  scrape_timeout = {{ .metrics.scrapeTimeout | default $.Values.global.scrapeTimeout | quote }}
  scrape_protocols = {{ include "helper.scrapeProtocols" $ }}
  scrape_classic_histograms = {{ $.Values.global.scrapeClassicHistograms }}
  scrape_native_histograms = {{ $.Values.global.scrapeNativeHistograms }}
  {{- if $emitPromRelabel }}
  forward_to = [prometheus.relabel.{{ $alloyName }}.receiver]
  {{- else }}
  forward_to = argument.metrics_destinations.value
  {{- end }}
}

{{- if $emitPromRelabel }}

prometheus.relabel {{ $alloyName | quote }} {
  {{- include "helper.relabelCacheArguments" (dict "maxCacheSize" .metrics.maxCacheSize "cacheTTL" .metrics.cacheTTL "global" $.Values.global) | nindent 2 }}
{{- if not .databaseObservability.enabled }}
  rule {
    target_label = "instance"
    replacement = {{ .name | quote }}
  }
  rule {
    target_label = "job"
    replacement = {{ $jobLabel | quote }}
  }
{{- end }}
{{- if .metrics.tuning.includeMetrics }}
  rule {
    source_labels = ["__name__"]
    regex = "up|scrape_samples_scraped|{{ .metrics.tuning.includeMetrics | join "|" }}"
    action = "keep"
  }
{{- end }}
{{- if .metrics.tuning.excludeMetrics }}
  rule {
    source_labels = ["__name__"]
    regex = {{ .metrics.tuning.excludeMetrics | join "|" | quote }}
    action = "drop"
  }
{{- end }}
{{- if .metrics.extraMetricProcessingRules }}
{{ .metrics.extraMetricProcessingRules | indent 2 }}
{{- end }}
  forward_to = argument.metrics_destinations.value
}
{{- end }}
{{- end }}
{{- end }}
{{- end }}
