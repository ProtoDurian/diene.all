{{- define "feature.prometheusOperatorObjects.serviceMonitors.alloy" }}
{{- if .Values.serviceMonitors.enabled }}
{{- $metricAllowList := .Values.serviceMonitors.metricsTuning.includeMetrics }}
{{- $metricDenyList := .Values.serviceMonitors.metricsTuning.excludeMetrics }}
{{- $namespacesHaveRegex := "" }}
{{- if .Values.serviceMonitors.namespaces }}
  {{- $namespacesHaveRegex = include "feature.prometheusOperatorObjects.namespaces.hasRegex" .Values.serviceMonitors.namespaces }}
{{- end }}
// Prometheus Operator ServiceMonitor objects
prometheus.operator.servicemonitors "service_monitors" {
  kubernetes_role = "endpointslice"
{{- if .Values.serviceMonitors.allowArbitraryFileAccess }}
  allow_arbitrary_file_access = true
{{- end }}
{{- if and .Values.serviceMonitors.namespaces (ne $namespacesHaveRegex "true") }}
  namespaces = {{ .Values.serviceMonitors.namespaces | toJson }}
{{- end }}
{{- if or .Values.serviceMonitors.labelSelectors .Values.serviceMonitors.labelExpressions }}
  selector {
  {{- if .Values.serviceMonitors.labelSelectors }}
    match_labels = {
    {{- range $key, $value := .Values.serviceMonitors.labelSelectors }}
      {{ $key | quote }} = {{ $value | quote }},
    {{- end }}
    }
  {{- end }}
  {{- range $expression := .Values.serviceMonitors.labelExpressions }}
    match_expression {
      key = {{ $expression.key | quote }}
      operator = {{ $expression.operator | quote }}
      {{ if $expression.values }}values = {{ $expression.values | toJson }}{{ end }}
    }
  {{- end }}
  }
{{- end }}
  clustering {
    enabled = true
  }
  scrape {
    default_scrape_interval = {{ .Values.serviceMonitors.scrapeInterval | default .Values.global.scrapeInterval | quote }}
    default_scrape_timeout = {{ .Values.serviceMonitors.scrapeTimeout | default .Values.global.scrapeTimeout | quote }}
    scrape_classic_histograms = {{ .Values.global.scrapeClassicHistograms }}
    scrape_native_histograms = {{ .Values.global.scrapeNativeHistograms }}
    convert_classic_histograms_to_nhcb = {{ .Values.global.convertClassicHistogramsToNhcb }}
    native_histogram_bucket_limit = {{ .Values.global.nativeHistogramBucketLimit | int }}
    native_histogram_min_bucket_factor = {{ .Values.global.nativeHistogramMinBucketFactor | float64 }}
  }

{{- if or (eq $namespacesHaveRegex "true") .Values.serviceMonitors.excludeNamespaces }}
  rule {  // extract the namespace from the job label (serviceMonitor/<namespace>/<name>/<index>) so the regexes below are matched against the namespace alone, and can't accidentally span into the name
    source_labels = ["job"]
    regex = "serviceMonitor/([^/]+)/.*"
    target_label = "__tmp_namespace"
  }
{{- end }}
{{- if eq $namespacesHaveRegex "true" }}
  rule {  // namespaces contains a regex, so ServiceMonitors cannot be pre-filtered by the component; keep only matching namespaces here
    source_labels = ["__tmp_namespace"]
    regex = {{ .Values.serviceMonitors.namespaces | join "|" | quote }}
    action = "keep"
  }
{{- end }}
{{- with .Values.serviceMonitors.excludeNamespaces }}
  rule {
    source_labels = ["__tmp_namespace"]
    regex = {{ . | join "|" | quote }}
    action = "drop"
  }
{{- end }}
{{- if .Values.serviceMonitors.extraDiscoveryRules }}
{{ .Values.serviceMonitors.extraDiscoveryRules | indent 2 }}
{{- end }}
{{- if or $metricAllowList $metricDenyList .Values.serviceMonitors.extraMetricProcessingRules }}
  forward_to = [prometheus.relabel.servicemonitors.receiver]
} // prometheus.operator.servicemonitors "service_monitors"

prometheus.relabel "servicemonitors" {
  {{- include "helper.relabelCacheArguments" (dict "maxCacheSize" .Values.serviceMonitors.maxCacheSize "cacheTTL" .Values.serviceMonitors.cacheTTL "global" .Values.global) | nindent 2 }}
{{- if $metricAllowList }}
  rule {
    source_labels = ["__name__"]
    regex = "up|scrape_samples_scraped|{{ $metricAllowList | join "|" }}"
    action = "keep"
  }
{{- end }}
{{- if $metricDenyList }}
  rule {
    source_labels = ["__name__"]
    regex = {{ $metricDenyList | join "|" | quote }}
    action = "drop"
  }
{{- end }}
{{- if .Values.serviceMonitors.extraMetricProcessingRules }}
{{ .Values.serviceMonitors.extraMetricProcessingRules | indent 2 }}
{{- end }}
  forward_to = argument.metrics_destinations.value
} // prometheus.relabel "servicemonitors"
{{- else }}
  forward_to = argument.metrics_destinations.value
} // prometheus.operator.servicemonitors "service_monitors"
{{- end }}
{{- end }}
{{- end }}
