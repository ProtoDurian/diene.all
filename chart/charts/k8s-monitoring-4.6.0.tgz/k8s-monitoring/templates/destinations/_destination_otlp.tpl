{{ define "destinations.otlp.resourceAttributes.removeList" }}
{{- $destination := .destination }}
{{- $root := .root }}
{{- $removeList := list }}
{{ if $destination.processors.resourceAttributes.useDefaultRemoveList }}
{{- $removeList = ($root.Files.Get "default-remove-lists/resource-attributes.yaml" | fromYamlArray) -}}
{{ end }}
{{ if $destination.processors.resourceAttributes.removeList }}
{{- $removeList = concat $removeList $destination.processors.resourceAttributes.removeList -}}
{{ end }}
{{ $removeList | uniq | toYaml }}
{{ end }}

{{/* Print an OTLP destination Alloy config components */}}
{{/* Inputs: . (root object),  destination (string, name of destination), destinationName (name of this destination) */}}
{{- define "destinations.otlp.alloy" }}
{{- with .destination }}
{{- $clusterLabelOTTL := list }}
{{- $overwriteClusterLabel := .overwriteClusterLabel }}
{{- range $label := .clusterLabels }}
  {{- if $overwriteClusterLabel }}
    {{- if $.Values.cluster.nameFrom }}
      {{- $clusterLabelOTTL = append $clusterLabelOTTL (printf "string.format(`set(attributes[%%q], %%q)`, %s, %s)," ($label | quote) ($.Values.cluster.nameFrom)) }}
    {{- else }}
      {{- $clusterLabelOTTL = append $clusterLabelOTTL (printf "`set(attributes[%s], %s)`," ($label | quote) ($.Values.cluster.name | quote)) }}
    {{- end }}
  {{- else }}
    {{- if $.Values.cluster.nameFrom }}
      {{- $clusterLabelOTTL = append $clusterLabelOTTL (printf "string.format(`set(attributes[%%q], %%q) where attributes[%%q] == nil`, %s, %s, %s)," ($label | quote) ($.Values.cluster.nameFrom) ($label | quote)) }}
    {{- else }}
      {{- $clusterLabelOTTL = append $clusterLabelOTTL (printf "`set(attributes[%s], %s) where attributes[%s] == nil`," ($label | quote) ($.Values.cluster.name | quote) ($label | quote)) }}
    {{- end }}
  {{- end }}
{{- end }}

{{- if eq (include "destinations.otlp.supports_metrics" .) "true" }}
otelcol.receiver.prometheus {{ include "helper.alloy_name" $.destinationName | quote }} {
  output {
    metrics = [otelcol.processor.transform.{{ include "helper.alloy_name" $.destinationName }}_scrape_normalize.input]
  }
} // otelcol.receiver.prometheus "{{ include "helper.alloy_name" $.destinationName }}"

// Repairs artifacts of the Prometheus-to-OTLP conversion performed by
// otelcol.receiver.prometheus. Only metrics that came from a Prometheus scrape pass
// through this component; OTLP-native telemetry enters the pipeline further down.
otelcol.processor.transform {{ printf "%s_scrape_normalize" (include "helper.alloy_name" $.destinationName) | quote }} {
  error_mode = {{ .processors.transform.errorMode | quote }}
  metric_statements {
    context = "resource"
    statements = [
      // The conversion sets service.name to the full Prometheus job label (e.g.
      // "namespace/workload"). When the scrape target declares its identity explicitly
      // with a service_name label on its own target_info metric (e.g. Grafana Beyla),
      // prefer that value and drop the duplicate.
      `set(attributes["service.name"], attributes["service_name"]) where attributes["service_name"] != nil and attributes["service_name"] != ""`,
      `delete_key(attributes, "service_name") where attributes["service_name"] == attributes["service.name"]`,
      // The same conversion turns other flat target_info labels into resource attributes.
      // Promote them to their OpenTelemetry counterparts and drop the flat duplicates, so
      // the OTLP endpoint does not receive two conflicting spellings of the same attribute.
      `set(attributes["service.namespace"], attributes["service_namespace"]) where (attributes["service.namespace"] == nil or attributes["service.namespace"] == "") and attributes["service_namespace"] != nil and attributes["service_namespace"] != ""`,
      `delete_key(attributes, "service_namespace") where attributes["service_namespace"] == attributes["service.namespace"]`,
      `set(attributes["deployment.environment"], attributes["deployment_environment"]) where (attributes["deployment.environment"] == nil or attributes["deployment.environment"] == "") and attributes["deployment_environment"] != nil and attributes["deployment_environment"] != ""`,
      `delete_key(attributes, "deployment_environment") where attributes["deployment_environment"] == attributes["deployment.environment"]`,
      `set(attributes["deployment.environment.name"], attributes["deployment_environment_name"]) where (attributes["deployment.environment.name"] == nil or attributes["deployment.environment.name"] == "") and attributes["deployment_environment_name"] != nil and attributes["deployment_environment_name"] != ""`,
      `delete_key(attributes, "deployment_environment_name") where attributes["deployment_environment_name"] == attributes["deployment.environment.name"]`,
    ]
  }
  metric_statements {
    context = "datapoint"
    statements = [
      // Same correction for scrape targets that put service_name on every series
      // instead of exposing a target_info metric.
      `set(resource.attributes["service.name"], attributes["service_name"]) where attributes["service_name"] != nil and attributes["service_name"] != ""`,
    ]
  }
  output {
    metrics = [{{ include "destinations.otlp.alloy.otlp.metrics.target" (dict "destination" . "destinationName" $.destinationName) | trim }}]
  }
} // otelcol.processor.transform "{{ include "helper.alloy_name" $.destinationName }}_scrape_normalize"
{{- end }}
{{- if eq (include "destinations.otlp.supports_logs" .) "true" }}
otelcol.receiver.loki {{ include "helper.alloy_name" $.destinationName | quote }} {
  output {
    logs = [{{ include "destinations.otlp.alloy.otlp.logs.target" (dict "destination" . "destinationName" $.destinationName) | trim }}]
  }
} // otelcol.receiver.loki "{{ include "helper.alloy_name" $.destinationName }}"
{{- end }}
otelcol.processor.attributes {{ include "helper.alloy_name" $.destinationName | quote }} {
{{- range $action := .processors.attributes.actions }}
  action {
    key = {{ $action.key | quote }}
    action = {{ $action.action | quote }}
    {{- if $action.value }}
    value = {{ $action.value | quote }}
    {{- else if $action.valueFrom }}
    value = {{ $action.valueFrom }}
    {{- end }}
    {{- if $action.pattern }}
    pattern = {{ $action.pattern | quote }}
    {{- end }}
    {{- if $action.fromAttribute }}
    from_attribute = {{ $action.fromAttribute | quote }}
    {{- end }}
    {{- if $action.fromContext }}
    from_context = {{ $action.fromContext | quote }}
    {{- end }}
    {{- if $action.convertedType }}
    converted_type = {{ $action.convertedType | quote }}
    {{- end }}
  }
{{- end }}
  output {
{{- if ne .metrics.enabled false }}
    metrics = [otelcol.processor.transform.{{ include "helper.alloy_name" $.destinationName }}.input]
{{- end }}
{{- if ne .logs.enabled false }}
    logs = [otelcol.processor.transform.{{ include "helper.alloy_name" $.destinationName }}.input]
{{- end }}
{{- if ne .traces.enabled false }}
    traces = [otelcol.processor.transform.{{ include "helper.alloy_name" $.destinationName }}.input]
{{- end }}
  }
} // otelcol.processor.attributes "{{ include "helper.alloy_name" $.destinationName }}"

otelcol.processor.transform {{ include "helper.alloy_name" $.destinationName | quote }} {
  error_mode = {{ .processors.transform.errorMode | quote }}

{{- if ne .metrics.enabled false }}
{{- $resourceAttributesToRemove := include "destinations.otlp.resourceAttributes.removeList" (dict "destination" . "root" $) | fromYamlArray }}
  metric_statements {
    context = "resource"
    statements = [{{ (join "\n" $clusterLabelOTTL) | nindent 6 }}
{{- range $key, $value := .extraResourceAttributes }}
      `set(attributes[{{ $key | quote }}], {{ $value | quote }})`,
{{- end }}
{{- range $key, $value := .extraResourceAttributesFrom }}
      string.format(`set(attributes[%q], %q)`, {{ $key | quote }}, {{ $value }}),
{{- end }}
{{- range $resourceAttribute := $resourceAttributesToRemove }}
      `delete_key(attributes, {{ $resourceAttribute | quote }})`,
{{- end }}
      // Scrape targets that expose their own target_info metric (e.g. Grafana Beyla) can
      // carry a flat k8s_cluster_name resource attribute, which conflicts with the
      // k8s.cluster.name attribute set above and gets ";"-joined by the Prometheus OTLP
      // endpoint. Drop the flat copy when the values match.
      `delete_key(attributes, "k8s_cluster_name") where attributes["k8s_cluster_name"] == attributes["k8s.cluster.name"]`,
{{- range $transform := .processors.transform.metrics.resource }}
{{ $transform | quote | indent 6 }},
{{- end }}
{{- range $transform := .processors.transform.metrics.resourceFrom }}
{{ $transform | indent 6 }},
{{- end }}
    ]
  }

{{- if or .processors.transform.metrics.metric .processors.transform.metrics.metricFrom }}
  metric_statements {
    context = "metric"
    statements = [
{{- range $transform := .processors.transform.metrics.metric }}
{{ $transform | quote | indent 6 }},
{{- end }}
{{- range $transform := .processors.transform.metrics.metricFrom }}
{{ $transform | indent 6 }},
{{- end }}
    ]
  }
{{- end }}

  metric_statements {
    context = "datapoint"
    statements = [{{ (join "\n" $clusterLabelOTTL) | nindent 6 }}
      // Scrape targets such as Grafana Beyla (3.20 and newer) put a flat k8s_cluster_name label on every
      // series. The cluster label statements above add k8s.cluster.name to the same datapoint, both
      // translate to the same Prometheus label, and the OTLP endpoint joins the values with ";". Drop
      // the flat copy when the values match.
      `delete_key(attributes, "k8s_cluster_name") where attributes["k8s_cluster_name"] == attributes["k8s.cluster.name"]`,
{{- range $datapointAttribute, $resourceAttribute := .processors.transform.metrics.datapointToResource }}
  {{- if $resourceAttribute }}
{{- if or (eq $resourceAttribute "service.name") (eq $resourceAttribute "service.namespace") }}
      `set(resource.attributes[{{ $resourceAttribute | quote }}], attributes[{{ $datapointAttribute | quote }}] ) where (resource.attributes[{{ $resourceAttribute | quote }}] == nil or resource.attributes[{{ $resourceAttribute | quote }}] == "") and attributes[{{ $datapointAttribute | quote }}] != nil and attributes[{{ $datapointAttribute | quote }}] != ""`,
      `delete_key(attributes, {{ $datapointAttribute | quote }}) where attributes[{{ $datapointAttribute | quote }}] == resource.attributes[{{ $resourceAttribute | quote }}]`,
{{- else }}
      `set(resource.attributes[{{ $resourceAttribute | quote }}], attributes[{{ $datapointAttribute | quote }}] ) where resource.attributes[{{ $resourceAttribute | quote }}] == nil and attributes[{{ $datapointAttribute | quote }}] != nil`,
      `delete_key(attributes, {{ $datapointAttribute | quote }}) where attributes[{{ $datapointAttribute | quote }}] == resource.attributes[{{ $resourceAttribute | quote }}]`,
{{- end }}
  {{- end }}
{{- end }}
{{- range $transform := .processors.transform.metrics.datapoint }}
{{ $transform | quote | indent 6 }},
{{- end }}
{{- range $transform := .processors.transform.metrics.datapointFrom }}
{{ $transform | indent 6 }},
{{- end }}
    ]
  }

{{- end }}
{{- if ne .logs.enabled false }}
{{- $resourceAttributesToRemove := include "destinations.otlp.resourceAttributes.removeList" (dict "destination" . "root" $) | fromYamlArray }}
  log_statements {
    context = "resource"
    statements = [{{ (join "\n" $clusterLabelOTTL) | nindent 6 }}
{{- range $key, $value := .extraResourceAttributes }}
      `set(attributes[{{ $key | quote }}], {{ $value | quote }})`,
{{- end }}
{{- range $key, $value := .extraResourceAttributesFrom }}
      string.format(`set(attributes[%q], %q)`, {{ $key | quote }}, {{ $value }}),
{{- end }}
{{- range $resourceAttribute := $resourceAttributesToRemove }}
      `delete_key(attributes, {{ $resourceAttribute | quote }})`,
{{- end }}
{{- range $transform := .processors.transform.logs.resource }}
{{ $transform | quote | indent 6 }},
{{- end }}
{{- range $transform := .processors.transform.logs.resourceFrom }}
{{ $transform | indent 6 }},
{{- end }}
    ]
  }

  log_statements {
    context = "log"
    statements = [
      `delete_key(attributes, "loki.attribute.labels")`,
      `delete_key(attributes, "loki.resource.labels")`,
{{- range $logAttribute, $resourceAttribute := .processors.transform.logs.logToResource }}
  {{- if $resourceAttribute }}
{{- if or (eq $resourceAttribute "service.name") (eq $resourceAttribute "service.namespace") }}
      `set(resource.attributes[{{ $resourceAttribute | quote }}], attributes[{{ $logAttribute | quote }}] ) where (resource.attributes[{{ $resourceAttribute | quote }}] == nil or resource.attributes[{{ $resourceAttribute | quote }}] == "") and attributes[{{ $logAttribute | quote }}] != nil and attributes[{{ $logAttribute | quote }}] != ""`,
      `delete_key(attributes, {{ $logAttribute | quote }}) where attributes[{{ $logAttribute | quote }}] == resource.attributes[{{ $resourceAttribute | quote }}]`,
{{- else }}
      `set(resource.attributes[{{ $resourceAttribute | quote }}], attributes[{{ $logAttribute | quote }}] ) where resource.attributes[{{ $resourceAttribute | quote }}] == nil and attributes[{{ $logAttribute | quote }}] != nil`,
      `delete_key(attributes, {{ $logAttribute | quote }}) where attributes[{{ $logAttribute | quote }}] == resource.attributes[{{ $resourceAttribute | quote }}]`,
{{- end }}
  {{- end }}
{{- end }}
{{- range $transform := .processors.transform.logs.log }}
{{ $transform | quote | indent 6 }},
{{- end }}
{{- range $transform := .processors.transform.logs.logFrom }}
{{ $transform | indent 6 }},
{{- end }}
    ]
  }
{{- if or .processors.transform.logs.scope .processors.transform.logs.scopeFrom }}
  log_statements {
    context = "scope"
    statements = [
{{- range $transform := .processors.transform.logs.scope }}
{{ $transform | quote | indent 6 }},
{{- end }}
{{- range $transform := .processors.transform.logs.scopeFrom }}
{{ $transform | indent 6 }},
{{- end }}
    ]
  }
{{- end }}
{{- end }}
{{- if ne .traces.enabled false }}
{{- $resourceAttributesToRemove := include "destinations.otlp.resourceAttributes.removeList" (dict "destination" . "root" $) | fromYamlArray }}

  trace_statements {
    context = "resource"
    statements = [{{ (join "\n" $clusterLabelOTTL) | nindent 6 }}
{{- range $key, $value := .extraResourceAttributes }}
      `set(attributes[{{ $key | quote }}], {{ $value | quote }})`,
{{- end }}
{{- range $key, $value := .extraResourceAttributesFrom }}
      string.format(`set(attributes[%q], %q)`, {{ $key | quote }}, {{ $value }}),
{{- end }}
{{- range $resourceAttribute := $resourceAttributesToRemove }}
      `delete_key(attributes, {{ $resourceAttribute | quote }})`,
{{- end }}
{{- range $transform := .processors.transform.traces.resource }}
{{ $transform | quote | indent 6 }},
{{- end }}
{{- range $transform := .processors.transform.traces.resourceFrom }}
{{ $transform | indent 6 }},
{{- end }}
      // Injected SDK resource attributes arrive as strings. Normalize the span metrics flag before export.
      `set(attributes["span.metrics.skip"], true) where attributes["span.metrics.skip"] == "true"`,
      `set(attributes["span.metrics.skip"], false) where attributes["span.metrics.skip"] == "false"`,
    ]
  }
{{- if or .processors.transform.traces.span .processors.transform.traces.spanFrom }}
  trace_statements {
    context = "span"
    statements = [
{{- range $transform := .processors.transform.traces.span }}
{{ $transform | quote | indent 6 }},
{{- end }}
{{- range $transform := .processors.transform.traces.spanFrom }}
{{ $transform | indent 6 }},
{{- end }}
    ]
  }
{{- end }}
{{- if or .processors.transform.traces.spanevent .processors.transform.traces.spaneventFrom }}
  trace_statements {
    context = "spanevent"
    statements = [
{{- range $transform := .processors.transform.traces.spanevent }}
{{ $transform | quote | indent 6 }},
{{- end }}
{{- range $transform := .processors.transform.traces.spaneventFrom }}
{{ $transform | indent 6 }},
{{- end }}
    ]
  }
{{- end }}
{{- end }}
{{- if .processors.filters.enabled }}

  output {
{{- if ne .metrics.enabled false }}
    metrics = [otelcol.processor.filter.{{ include "helper.alloy_name" $.destinationName }}.input]
{{- end }}
{{- if ne .logs.enabled false }}
    logs = [otelcol.processor.filter.{{ include "helper.alloy_name" $.destinationName }}.input]
{{- end }}
{{- if ne .traces.enabled false }}
    traces = [otelcol.processor.filter.{{ include "helper.alloy_name" $.destinationName }}.input]
{{- end }}
  }
} // otelcol.processor.transform "{{ include "helper.alloy_name" $.destinationName }}"

otelcol.processor.filter {{ include "helper.alloy_name" $.destinationName | quote }} {
  error_mode = {{ .processors.filters.errorMode | quote }}

{{- if and .metrics.enabled (or .processors.filters.metrics.metric .processors.filters.metrics.datapoint) }}
  metrics {
{{- if .processors.filters.metrics.metric }}
    metric = [
{{- range $filter := .processors.filters.metrics.metric }}
{{ $filter | quote | indent 6 }},
{{- end }}
    ]
{{- end }}
{{- if .processors.filters.metrics.datapoint }}
    datapoint = [
{{- range $filter := .processors.filters.metrics.datapoint }}
{{ $filter | quote | indent 6 }},
{{- end }}
    ]
{{- end }}
  }
{{- end }}
{{- if and .logs.enabled .processors.filters.logs.logRecord }}
  logs {
    log_record = [
{{- range $filter := .processors.filters.logs.logRecord }}
{{ $filter | quote | indent 6 }},
{{- end }}
    ]
  }
{{- end }}
{{- if and .traces.enabled (or .processors.filters.traces.span .processors.filters.traces.spanevent) }}
  traces {
{{- if .processors.filters.traces.span }}
    span = [
{{- range $filter := .processors.filters.traces.span }}
{{ $filter | quote | indent 6 }},
{{- end }}
    ]
{{- end }}
{{- if .processors.filters.traces.spanevent }}
    spanevent = [
{{- range $filter := .processors.filters.traces.spanevent }}
{{ $filter | quote | indent 6 }},
{{- end }}
    ]
{{- end }}
  }
{{- end }}
{{- end }}

  output {
{{- if ne .metrics.enabled false }}
    metrics = [{{ include "destinations.otlp.alloy.exporter.target" (dict "destination" . "destinationName" $.destinationName) }}]
{{- end }}
{{- if ne .logs.enabled false }}
    logs = [{{ include "destinations.otlp.alloy.exporter.target" (dict "destination" . "destinationName" $.destinationName) }}]
{{- end }}
{{- if ne .traces.enabled false }}
{{- /* If sampling is enabled, override traces target and enable loadbalancing exporter if sampling is enabled */}}
{{- if and .processors.tailSampling.enabled .processors.serviceGraphMetrics.enabled }}
    traces = [
      otelcol.exporter.loadbalancing.{{ printf "%s_sampler" (include "helper.alloy_name" $.destinationName) }}.input,
      otelcol.exporter.loadbalancing.{{ printf "%s_servicegraph" (include "helper.alloy_name" $.destinationName) }}.input,
    ]
{{- else if .processors.tailSampling.enabled }}
    traces = [otelcol.exporter.loadbalancing.{{ printf "%s_sampler" (include "helper.alloy_name" $.destinationName) }}.input]
{{- else if .processors.serviceGraphMetrics.enabled }}
    traces = [
      otelcol.exporter.loadbalancing.{{ printf "%s_servicegraph" (include "helper.alloy_name" $.destinationName) }}.input,
      {{ include "destinations.otlp.alloy.exporter.target" (dict "destination" . "destinationName" $.destinationName) }},
    ]
{{- else }}
    traces = [{{ include "destinations.otlp.alloy.exporter.target" (dict "destination" . "destinationName" $.destinationName) }}]
{{- end }}
{{- end }}
  }
} {{- if .processors.filters.enabled }} // otelcol.processor.filter "{{ include "helper.alloy_name" $.destinationName }}"{{- else }} // otelcol.processor.transform "{{ include "helper.alloy_name" $.destinationName }}"{{- end }}

{{- if .processors.tailSampling.enabled }}

otelcol.exporter.loadbalancing {{ printf "%s_sampler" (include "helper.alloy_name" $.destinationName) | quote }} {
  resolver {
    {{- $maxLength := 51 }}{{/* This limit is from the `controller-revision-hash` pod label value*/}}
    {{- $collectorName := printf "%s-%s" $.Release.Name (include "helper.k8s_name" (printf "%s-sampler" $.destinationName)) | trunc $maxLength | trimSuffix "-" | lower }}
{{- if eq .processors.tailSampling.loadBalancer.resolver "kubernetes" }}
    kubernetes {
      service = "{{ $collectorName }}"
      ports   = [4317]
      timeout = {{ .processors.tailSampling.loadBalancer.timeout | quote }}
    }
{{- else if eq .processors.tailSampling.loadBalancer.resolver "dns" }}
    dns {
      hostname = "{{ $collectorName }}.{{ include "helper.namespace" $ }}.svc.cluster.local"
      port     = "4317"
      timeout = {{ .processors.tailSampling.loadBalancer.timeout | quote }}
    }
{{- else if eq .processors.tailSampling.loadBalancer.resolver "static" }}
    static {
      hostnames = [
{{- $replicas := int (dig "collector" "controller" "replicas" 1 .processors.tailSampling) }}
{{- range $i := until $replicas }}
        "{{ $collectorName }}-{{ $i }}.{{ $collectorName }}.{{ include "helper.namespace" $ }}.svc.cluster.local:4317",
{{- end }}
      ]
    }
{{- end }}
  }
  protocol {
    otlp {
      client {
        tls {
          insecure = true
        }
      }
    }
  }
} // otelcol.exporter.loadbalancing "{{ printf "%s_sampler" (include "helper.alloy_name" $.destinationName) }}"
{{- end }}

{{- if .processors.serviceGraphMetrics.enabled }}

otelcol.exporter.loadbalancing {{ printf "%s_servicegraph" (include "helper.alloy_name" $.destinationName) | quote }} {
  resolver {
    {{- $maxLength := 51 }}{{/* This limit is from the `controller-revision-hash` pod label value*/}}
    {{- $collectorName := printf "%s-%s" $.Release.Name (include "helper.k8s_name" (printf "%s-servicegraph" $.destinationName)) | trunc $maxLength | trimSuffix "-" | lower }}
{{- if eq .processors.serviceGraphMetrics.loadBalancer.resolver "kubernetes" }}
    kubernetes {
      service = "{{ $collectorName }}"
      ports   = [4317]
      timeout = {{ .processors.serviceGraphMetrics.loadBalancer.timeout | quote }}
    }
{{- else if eq .processors.serviceGraphMetrics.loadBalancer.resolver "dns" }}
    dns {
      hostname = "{{ $collectorName }}.{{ include "helper.namespace" $ }}.svc.cluster.local"
      port     = "4317"
      timeout = {{ .processors.serviceGraphMetrics.loadBalancer.timeout | quote }}
    }
{{- else if eq .processors.serviceGraphMetrics.loadBalancer.resolver "static" }}
    static {
      hostnames = [
{{- $replicas := int (dig "collector" "controller" "replicas" 1 .processors.serviceGraphMetrics) }}
{{- range $i := until $replicas }}
        "{{ $collectorName }}-{{ $i }}.{{ $collectorName }}.{{ include "helper.namespace" $ }}.svc.cluster.local:4317",
{{- end }}
      ]
    }
{{- end }}
  }
  protocol {
    otlp {
      client {
        tls {
          insecure = true
        }
      }
    }
  }
} // otelcol.exporter.loadbalancing "{{ printf "%s_servicegraph" (include "helper.alloy_name" $.destinationName) }}"
{{- end }}
{{ include "destinations.otlp.alloy.exporter" $ }}
{{- end }}
{{- end }}

{{- define "destinations.otlp.alloy.exporter.target" }}
{{- if .destination.processors.batch.enabled -}}
otelcol.processor.batch.{{ include "helper.alloy_name" $.destinationName }}.input
{{- else if .destination.processors.memoryLimiter.enabled -}}
otelcol.processor.memory_limiter.{{ include "helper.alloy_name" $.destinationName }}.input
{{- else if eq .destination.protocol "grpc" -}}
otelcol.exporter.otlp.{{ include "helper.alloy_name" $.destinationName }}.input
{{- else if eq .destination.protocol "http" -}}
otelcol.exporter.otlphttp.{{ include "helper.alloy_name" $.destinationName }}.input
{{- end }}
{{- end }}

{{- define "destinations.otlp.alloy.exporter" }}
{{- with .destination }}
{{- if .processors.batch.enabled }}
otelcol.processor.batch {{ include "helper.alloy_name" $.destinationName | quote }} {
  timeout = {{ .processors.batch.timeout | quote }}
  send_batch_size = {{ .processors.batch.size | int }}
  send_batch_max_size = {{ .processors.batch.maxSize | int }}
{{- end }}

  output {
{{- $target := "" }}
{{- if .processors.memoryLimiter.enabled }}
  {{- $target = printf "otelcol.processor.memory_limiter.%s.input" (include "helper.alloy_name" $.destinationName) }}
{{- else if eq .protocol "grpc" }}
  {{- $target = printf "otelcol.exporter.otlp.%s.input" (include "helper.alloy_name" $.destinationName) }}
{{- else if eq .protocol "http" }}
  {{- $target = printf "otelcol.exporter.otlphttp.%s.input" (include "helper.alloy_name" $.destinationName) }}
{{- end }}
{{- if ne .metrics.enabled false }}
    metrics = [{{ $target }}]
{{- end }}
{{- if ne .logs.enabled false }}
    logs = [{{ $target }}]
{{- end }}
{{- if ne .traces.enabled false }}
    traces = [{{ $target }}]
{{- end }}
  }
} {{- if .processors.batch.enabled }} // otelcol.processor.batch "{{ include "helper.alloy_name" $.destinationName }}"{{- end }}
{{- if .processors.memoryLimiter.enabled }}

otelcol.processor.memory_limiter {{ include "helper.alloy_name" $.destinationName | quote }} {
  check_interval = {{ .processors.memoryLimiter.checkInterval | quote }}
  limit = {{ .processors.memoryLimiter.limit | quote }}

  output {
{{- if eq .protocol "grpc" }}
  {{- $target = printf "otelcol.exporter.otlp.%s.input" (include "helper.alloy_name" $.destinationName) }}
{{- else if eq .protocol "http" }}
  {{- $target = printf "otelcol.exporter.otlphttp.%s.input" (include "helper.alloy_name" $.destinationName) }}
{{- end }}
{{- if ne .metrics.enabled false }}
    metrics = [{{ $target }}]
{{- end }}
{{- if ne .logs.enabled false }}
    logs = [{{ $target }}]
{{- end }}
{{- if ne .traces.enabled false }}
    traces = [{{ $target }}]
{{- end }}
  }
} // otelcol.processor.memory_limiter "{{ include "helper.alloy_name" $.destinationName }}"
{{- end }}

{{- if eq .protocol "grpc" }}
otelcol.exporter.otlp {{ include "helper.alloy_name" $.destinationName | quote }} {
{{- if .timeout }}
  timeout = {{ .timeout | quote }}
{{- end }}
{{- else if eq .protocol "http" }}
otelcol.exporter.otlphttp {{ include "helper.alloy_name" $.destinationName | quote }} {
{{- if and (ne .metrics.enabled false) .metrics.path }}
{{- $path := .metrics.path | trimPrefix "/" }}
{{- if .urlFrom }}
  metrics_endpoint = {{ .urlFrom }} + {{ printf "/%s" $path | quote }}
{{- else }}
  metrics_endpoint = {{ printf "%s/%s" (.url | trimSuffix "/") $path | quote }}
{{- end }}
{{- end }}
{{- if and (ne .logs.enabled false) .logs.path }}
{{- $path := .logs.path | trimPrefix "/" }}
{{- if .urlFrom }}
  logs_endpoint = {{ .urlFrom }} + {{ printf "/%s" $path | quote }}
{{- else }}
  logs_endpoint = {{ printf "%s/%s" (.url | trimSuffix "/") $path | quote }}
{{- end }}
{{- end }}
{{- if and (ne .traces.enabled false) .traces.path }}
{{- $path := .traces.path | trimPrefix "/" }}
{{- if .urlFrom }}
  traces_endpoint = {{ .urlFrom }} + {{ printf "/%s" $path | quote }}
{{- else }}
  traces_endpoint = {{ printf "%s/%s" (.url | trimSuffix "/") $path | quote }}
{{- end }}
{{- end }}
{{- end }}
  client {
{{- if and .timeout (eq .protocol "http") }}
    timeout = {{ .timeout | quote }}
{{- end }}
{{- if .urlFrom }}
    endpoint = {{ .urlFrom }}
{{- else }}
    endpoint = {{ .url | quote }}
{{- end }}
{{- if .proxyURL }}
    proxy_url = {{ .proxyURL | quote }}
{{- end }}
{{- if eq (include "secrets.authType" .) "basic" }}
    auth = otelcol.auth.basic.{{ include "helper.alloy_name" $.destinationName }}.handler
{{- else if eq (include "secrets.authType" .) "bearerToken" }}
    auth = otelcol.auth.bearer.{{ include "helper.alloy_name" $.destinationName }}.handler
{{- else if eq (include "secrets.authType" .) "oauth2" }}
    auth = otelcol.auth.oauth2.{{ include "helper.alloy_name" $.destinationName }}.handler
{{- else if eq (include "secrets.authType" .) "sigv4" }}
    auth = otelcol.auth.sigv4.{{ include "helper.alloy_name" $.destinationName }}.handler
{{- end }}
{{- if or (eq (include "secrets.usesSecret" (dict "object" . "name" $.destinationName "key" "tenantId")) "true") .extraHeaders .extraHeadersFrom }}
    headers = {
{{- if eq (include "secrets.usesSecret" (dict "object" . "name" $.destinationName "key" "tenantId")) "true" }}
      "X-Scope-OrgID" = {{ include "secrets.read" (dict "object" . "name" $.destinationName "key" "tenantId" "nonsensitive" true) }},
{{- end }}
{{- range $key, $value := .extraHeaders }}
      {{ $key | quote }} = {{ $value | quote }},
{{- end }}
{{- range $key, $value := .extraHeadersFrom }}
      {{ $key | quote }} = {{ $value }},
{{- end }}
    }
{{- end }}
{{- if .readBufferSize }}
    read_buffer_size = {{ .readBufferSize | quote }}
{{- end }}
{{- if .writeBufferSize }}
    write_buffer_size = {{ .writeBufferSize | quote }}
{{- end }}

{{- if .tls }}
    tls {
      insecure = {{ .tls.insecure | default false }}
      insecure_skip_verify = {{ .tls.insecureSkipVerify | default false }}
      {{- if .tls.caFile }}
      ca_file = {{ .tls.caFile | quote }}
      {{- else if eq (include "secrets.usesSecret" (dict "object" . "name" $.destinationName "key" "tls.ca")) "true" }}
      ca_pem = {{ include "secrets.read" (dict "object" . "name" $.destinationName "key" "tls.ca" "nonsensitive" true) }}
      {{- end }}
      {{- if .tls.certFile }}
      cert_file = {{ .tls.certFile | quote }}
      {{- else if eq (include "secrets.usesSecret" (dict "object" . "name" $.destinationName "key" "tls.cert")) "true" }}
      cert_pem = {{ include "secrets.read" (dict "object" . "name" $.destinationName "key" "tls.cert" "nonsensitive" true) }}
      {{- end }}
      {{- if .tls.keyFile }}
      key_file = {{ .tls.keyFile | quote }}
      {{- else if eq (include "secrets.usesSecret" (dict "object" . "name" $.destinationName "key" "tls.key")) "true" }}
      key_pem = {{ include "secrets.read" (dict "object" . "name" $.destinationName "key" "tls.key") }}
      {{- end }}
    }
{{- end }}
  }

  retry_on_failure {
    enabled = {{ .retryOnFailure.enabled }}
    initial_interval = {{ .retryOnFailure.initialInterval | quote }}
    max_interval = {{ .retryOnFailure.maxInterval | quote }}
    max_elapsed_time = {{ .retryOnFailure.maxElapsedTime | quote }}
  }

  sending_queue {
    enabled = {{ .sendingQueue.enabled }}
{{- if .sendingQueue.blockOnOverflow }}
    block_on_overflow = {{ .sendingQueue.blockOnOverflow }}
{{- end }}
{{- if .sendingQueue.numConsumers }}
    num_consumers = {{ .sendingQueue.numConsumers | int }}
{{- end }}
{{- if .sendingQueue.queueSize }}
    queue_size = {{ .sendingQueue.queueSize | int }}
{{- end }}
{{- if and .sendingQueue.sizer (not .sendingQueue.batch.enabled) }}
    sizer = {{ .sendingQueue.sizer | quote }}
{{- end }}
{{- if .sendingQueue.storage }}
    storage = {{ .sendingQueue.storage }}
{{- end }}
{{- if .sendingQueue.batch.enabled }}
    batch {
      sizer = {{ .sendingQueue.batch.sizer | quote }}
      flush_timeout = {{ .sendingQueue.batch.flushTimeout | quote }}
      min_size = {{ .sendingQueue.batch.minSize | int }}
      max_size = {{ .sendingQueue.batch.maxSize | int }}
    }
{{- end }}
  }
} {{- if eq .protocol "grpc" }} // otelcol.exporter.otlp "{{ include "helper.alloy_name" $.destinationName }}"{{- else if eq .protocol "http" }} // otelcol.exporter.otlphttp "{{ include "helper.alloy_name" $.destinationName }}"{{- end }}
{{- if eq (include "secrets.authType" .) "basic" }}

otelcol.auth.basic {{ include "helper.alloy_name" $.destinationName | quote }} {
  username = {{ include "secrets.read" (dict "object" . "name" $.destinationName "key" "auth.username" "nonsensitive" true) }}
  password = {{ include "secrets.read" (dict "object" . "name" $.destinationName "key" "auth.password") }}
} // otelcol.auth.basic "{{ include "helper.alloy_name" $.destinationName }}"
{{- else if eq (include "secrets.authType" .) "bearerToken" }}
{{- if .auth.bearerTokenFile }}

local.file {{ include "helper.alloy_name" $.destinationName | quote }} {
  filename = {{ .auth.bearerTokenFile | quote }}
} // local.file "{{ include "helper.alloy_name" $.destinationName }}"

otelcol.auth.bearer {{ include "helper.alloy_name" $.destinationName | quote }} {
  token = local.file.{{ include "helper.alloy_name" $.destinationName }}.content
} // otelcol.auth.bearer "{{ include "helper.alloy_name" $.destinationName }}"
{{- else }}

otelcol.auth.bearer {{ include "helper.alloy_name" $.destinationName | quote }} {
  token = {{ include "secrets.read" (dict "object" . "name" $.destinationName "key" "auth.bearerToken") }}
} // otelcol.auth.bearer "{{ include "helper.alloy_name" $.destinationName }}"
{{- end }}
{{- else if eq (include "secrets.authType" .) "oauth2" }}

otelcol.auth.oauth2 {{ include "helper.alloy_name" $.destinationName | quote }} {
  {{- if eq (include "secrets.usesSecret" (dict "object" . "name" $.destinationName "key" "auth.oauth2.clientId")) "true" }}
  client_id = {{ include "secrets.read" (dict "object" . "name" $.destinationName "key" "auth.oauth2.clientId" "nonsensitive" true) }}
  {{- end }}
  {{- if .auth.oauth2.clientSecretFile }}
  client_secret_file = {{ .auth.oauth2.clientSecretFile | quote }}
  {{- else if eq (include "secrets.usesSecret" (dict "object" . "name" $.destinationName "key" "auth.oauth2.clientSecret")) "true" }}
  client_secret = {{ include "secrets.read" (dict "object" . "name" $.destinationName "key" "auth.oauth2.clientSecret") }}
  {{- end }}
  {{- if .auth.oauth2.endpointParams }}
  endpoint_params = {
  {{- range $k, $v := .auth.oauth2.endpointParams }}
    {{ $k }} = {{ $v | toJson }},
  {{- end }}
  }
  {{- end }}
  {{- if .auth.oauth2.proxyURL }}
  proxy_url = {{ .auth.oauth2.proxyURL | quote }}
  {{- end }}
  {{- if .auth.oauth2.noProxy }}
  no_proxy = {{ .auth.oauth2.noProxy | quote }}
  {{- end }}
  {{- if .auth.oauth2.proxyFromEnvironment }}
  proxyFromEnvironment = {{ .auth.oauth2.proxyFromEnvironment }}
  {{- end }}
  {{- if .auth.oauth2.proxyConnectHeader }}
  proxy_connect_header = {
  {{- range $k, $v := .auth.oauth2.proxyConnectHeader }}
    {{ $k | quote }} = {{ $v | toJson }},
  {{- end }}
  }
  {{- end }}
  {{- if .auth.oauth2.scopes }}
  scopes = {{ .auth.oauth2.scopes | toJson }}
  {{- end }}
  {{- if .auth.oauth2.tokenURL }}
  token_url = {{ .auth.oauth2.tokenURL | quote }}
  {{- end }}
  {{- if .auth.oauth2.tls }}
  tls {
    insecure_skip_verify = {{ .auth.oauth2.tls.insecureSkipVerify | default false }}
    {{- if .auth.oauth2.tls.caFile }}
    ca_file = {{ .auth.oauth2.tls.caFile | quote }}
    {{- else if eq (include "secrets.usesSecret" (dict "object" . "name" $.destinationName "key" "auth.oauth2.tls.ca")) "true" }}
    ca_pem = {{ include "secrets.read" (dict "object" . "name" $.destinationName "key" "auth.oauth2.tls.ca" "nonsensitive" true) }}
    {{- end }}
    {{- if .auth.oauth2.tls.certFile }}
    cert_file = {{ .auth.oauth2.tls.certFile | quote }}
    {{- else if eq (include "secrets.usesSecret" (dict "object" . "name" $.destinationName "key" "auth.oauth2.tls.cert")) "true" }}
    cert_pem = {{ include "secrets.read" (dict "object" . "name" $.destinationName "key" "auth.oauth2.tls.cert" "nonsensitive" true) }}
    {{- end }}
    {{- if .auth.oauth2.tls.keyFile }}
    key_file = {{ .auth.oauth2.tls.keyFile | quote }}
    {{- else if eq (include "secrets.usesSecret" (dict "object" . "name" $.destinationName "key" "auth.oauth2.tls.key")) "true" }}
    key_pem = {{ include "secrets.read" (dict "object" . "name" $.destinationName "key" "auth.oauth2.tls.key") }}
    {{- end }}
  }
  {{- end }}
} // otelcol.auth.oauth2 "{{ include "helper.alloy_name" $.destinationName }}"
{{- else if eq (include "secrets.authType" .) "sigv4" }}

otelcol.auth.sigv4 {{ include "helper.alloy_name" $.destinationName | quote }} {
  {{- if .auth.sigv4.region }}
  region = {{ .auth.sigv4.region | quote }}
  {{- end }}
  {{- if .auth.sigv4.service }}
  service = {{ .auth.sigv4.service | quote }}
  {{- end }}
  {{- if (or .auth.sigv4.assumeRole.arn .auth.sigv4.assumeRole.sessionName .auth.sigv4.assumeRole.stsRegion) }}
  assume_role {
    {{- if .auth.sigv4.assumeRole.arn }}
    arn = {{ .auth.sigv4.assumeRole.arn | quote }}
    {{- end }}
    {{- if .auth.sigv4.assumeRole.sessionName }}
    session_name = {{ .auth.sigv4.assumeRole.sessionName | quote }}
    {{- end }}
    {{- if .auth.sigv4.assumeRole.stsRegion }}
    sts_region = {{ .auth.sigv4.assumeRole.stsRegion | quote }}
    {{- end }}
  }
  {{- end }}
} // otelcol.auth.sigv4 "{{ include "helper.alloy_name" $.destinationName }}"
{{- end }}
{{- end }}
{{- end }}

{{- define "secrets.list.otlp" -}}
- tenantId
- auth.username
- auth.password
- auth.bearerToken
- auth.oauth2.clientId
- auth.oauth2.clientSecret
- auth.oauth2.tls.ca
- auth.oauth2.tls.cert
- auth.oauth2.tls.key
- tls.ca
- tls.cert
- tls.key
{{- end -}}

{{- define "destinations.otlp.alloy.prometheus.metrics.target" }}otelcol.receiver.prometheus.{{ include "helper.alloy_name" $.destinationName }}.receiver{{ end }}
{{- define "destinations.otlp.alloy.loki.logs.target" }}otelcol.receiver.loki.{{ include "helper.alloy_name" $.destinationName }}.receiver{{ end }}
{{- define "destinations.otlp.alloy.otlp.target" }}otelcol.processor.attributes.{{ include "helper.alloy_name" $.destinationName }}.input{{ end }}
{{- define "destinations.otlp.alloy.otlp.metrics.target" }}{{ include "destinations.otlp.alloy.otlp.target" . }}{{- end }}
{{- define "destinations.otlp.alloy.otlp.logs.target" }}{{ include "destinations.otlp.alloy.otlp.target" . }}{{- end }}
{{- define "destinations.otlp.alloy.otlp.traces.target" }}{{ include "destinations.otlp.alloy.otlp.target" . }}{{- end }}

{{- define "destinations.otlp.supports_metrics" }}{{ dig "metrics" "enabled" "true" . }}{{ end -}}
{{- define "destinations.otlp.supports_logs" }}{{ dig "logs" "enabled" "true" . }}{{ end -}}
{{- define "destinations.otlp.supports_traces" }}{{ dig "traces" "enabled" "true" . }}{{ end -}}
{{- define "destinations.otlp.supports_profiles" }}false{{ end -}}
{{- define "destinations.otlp.ecosystem" }}otlp{{ end -}}

{{- define "destinations.otlp.isTailSamplingEnabled" }}
{{- dig "processors" "tailSampling" "enabled" "false" . -}}
{{- end -}}

{{- define "destinations.otlp.isServiceGraphsEnabled" }}
{{- dig "processors" "serviceGraphMetrics" "enabled" "false" . -}}
{{- end -}}
