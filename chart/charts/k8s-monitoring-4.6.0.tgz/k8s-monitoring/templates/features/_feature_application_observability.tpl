{{- define "features.applicationObservability.enabled" }}{{ .Values.applicationObservability.enabled }}{{- end }}

{{- define "features.applicationObservability.include" }}
{{- if .Values.applicationObservability.enabled -}}
{{- $metricsDestinations := include "destinations.get" (dict "destinations" $.Values.destinations "type" "metrics" "ecosystem" "otlp" "filter" $.Values.applicationObservability.destinations) | fromYamlArray }}
{{- $logsDestinations := include "destinations.get" (dict "destinations" $.Values.destinations "type" "logs" "ecosystem" "otlp" "filter" $.Values.applicationObservability.destinations) | fromYamlArray }}
{{- $tracesDestinations := include "destinations.get" (dict "destinations" $.Values.destinations "type" "traces" "ecosystem" "otlp" "filter" $.Values.applicationObservability.destinations) | fromYamlArray }}

// Feature: Application Observability
{{- include "feature.applicationObservability.module" (dict "Values" $.Values.applicationObservability "Files" $.Subcharts.applicationObservability.Files) }}
application_observability "feature" {
  metrics_destinations = [
    {{ include "dataProcessors.pipeline.targets.forFeature" (dict "root" $ "featureKey" "applicationObservability" "destinationNames" $metricsDestinations "type" "metrics" "ecosystem" "otlp") | indent 4 | trim }}
  ]
  logs_destinations = [
    {{ include "dataProcessors.pipeline.targets.forFeature" (dict "root" $ "featureKey" "applicationObservability" "destinationNames" $logsDestinations "type" "logs" "ecosystem" "otlp") | indent 4 | trim }}
  ]
  traces_destinations = [
    {{ include "dataProcessors.pipeline.targets.forFeature" (dict "root" $ "featureKey" "applicationObservability" "destinationNames" $tracesDestinations "type" "traces" "ecosystem" "otlp") | indent 4 | trim }}
  ]
}
{{- include "dataProcessors.pipeline.render.forFeature" (dict "root" $ "featureKey" "applicationObservability" "destinationNames" $metricsDestinations "type" "metrics" "ecosystem" "otlp") }}
{{- include "dataProcessors.pipeline.render.forFeature" (dict "root" $ "featureKey" "applicationObservability" "destinationNames" $logsDestinations "type" "logs" "ecosystem" "otlp") }}
{{- include "dataProcessors.pipeline.render.forFeature" (dict "root" $ "featureKey" "applicationObservability" "destinationNames" $tracesDestinations "type" "traces" "ecosystem" "otlp") }}
{{- end -}}
{{- end -}}

{{- define "features.applicationObservability.destinations" }}
{{- if .Values.applicationObservability.enabled -}}
{{- $metricsDestinations := include "destinations.get" (dict "destinations" $.Values.destinations "type" "metrics" "ecosystem" "otlp" "filter" $.Values.applicationObservability.destinations) | fromYamlArray -}}
{{- $logDestinations     := include "destinations.get" (dict "destinations" $.Values.destinations "type" "logs"    "ecosystem" "otlp" "filter" $.Values.applicationObservability.destinations) | fromYamlArray -}}
{{- $traceDestinations   := include "destinations.get" (dict "destinations" $.Values.destinations "type" "traces"  "ecosystem" "otlp" "filter" $.Values.applicationObservability.destinations) | fromYamlArray -}}
{{- (concat $metricsDestinations $logDestinations $traceDestinations) | uniq | sortAlpha | toYaml }}
{{- end -}}
{{- end -}}

{{- define "features.applicationObservability.destinations.isTranslating" }}
{{- $isTranslating := false -}}
{{- $destinations := include "features.applicationObservability.destinations" . | fromYamlArray -}}
{{ range $destination := $destinations -}}
  {{- $destinationEcosystem := include "destination.getEcosystem" (deepCopy $ | merge (dict "destination" $destination)) -}}
  {{- if ne $destinationEcosystem "otlp" -}}
    {{- $isTranslating = true -}}
  {{- end -}}
{{- end -}}
{{- $isTranslating -}}
{{- end -}}

{{- define "features.applicationObservability.collector.values" }}
{{- if .Values.applicationObservability.enabled -}}
  {{- $values := dict }}
  {{- $collectorName := include "collectors.getCollectorForFeature" (dict "Values" $.Values "featureKey" "applicationObservability") }}
  {{- $collectorValues := (include "collector.alloy.values" (dict "Values" $.Values "Files" $.Files "collectorName" $collectorName) | fromYaml) }}
  {{- $extraPorts := deepCopy (dig "alloy" "extraPorts" list $collectorValues) }}
  {{- if $.Values.applicationObservability.receivers.otlp.grpc.enabled }}
    {{- if eq (include "collectors.hasExtraPort" (dict "collectorValues" $collectorValues "portNumber" $.Values.applicationObservability.receivers.otlp.grpc.port)) "false" }}
      {{- $extraPorts = append $extraPorts (dict "name" "otlp-grpc" "port" $.Values.applicationObservability.receivers.otlp.grpc.port "targetPort" $.Values.applicationObservability.receivers.otlp.grpc.port "protocol" "TCP" "appProtocol" "grpc") }}
    {{- end -}}
  {{- end -}}
  {{- if $.Values.applicationObservability.receivers.otlp.http.enabled }}
    {{- if eq (include "collectors.hasExtraPort" (dict "collectorValues" $collectorValues "portNumber" $.Values.applicationObservability.receivers.otlp.http.port)) "false" }}
      {{- $extraPorts = append $extraPorts (dict "name" "otlp-http" "port" $.Values.applicationObservability.receivers.otlp.http.port "targetPort" $.Values.applicationObservability.receivers.otlp.http.port "protocol" "TCP" "appProtocol" "http") }}
    {{- end -}}
  {{- end -}}
  {{- if $.Values.applicationObservability.receivers.zipkin.enabled }}
    {{- if eq (include "collectors.hasExtraPort" (dict "collectorValues" $collectorValues "portNumber" $.Values.applicationObservability.receivers.zipkin.port)) "false" }}
      {{- $extraPorts = append $extraPorts (dict "name" "zipkin" "port" $.Values.applicationObservability.receivers.zipkin.port "targetPort" $.Values.applicationObservability.receivers.zipkin.port "protocol" "TCP" "appProtocol" "http") }}
    {{- end -}}
  {{- end -}}
  {{- if $.Values.applicationObservability.receivers.jaeger.grpc.enabled }}
    {{- if eq (include "collectors.hasExtraPort" (dict "collectorValues" $collectorValues "portNumber" $.Values.applicationObservability.receivers.jaeger.grpc.port)) "false" }}
      {{- $extraPorts = append $extraPorts (dict "name" "jaeger-grpc" "port" $.Values.applicationObservability.receivers.jaeger.grpc.port "targetPort" $.Values.applicationObservability.receivers.jaeger.grpc.port "protocol" "TCP" "appProtocol" "grpc") }}
    {{- end -}}
  {{- end -}}
  {{- if $.Values.applicationObservability.receivers.jaeger.thriftBinary.enabled }}
    {{- if eq (include "collectors.hasExtraPort" (dict "collectorValues" $collectorValues "portNumber" $.Values.applicationObservability.receivers.jaeger.thriftBinary.port)) "false" }}
      {{- $extraPorts = append $extraPorts (dict "name" "jaeger-binary" "port" $.Values.applicationObservability.receivers.jaeger.thriftBinary.port "targetPort" $.Values.applicationObservability.receivers.jaeger.thriftBinary.port "protocol" "UDP") }}
    {{- end -}}
  {{- end -}}
  {{- if $.Values.applicationObservability.receivers.jaeger.thriftCompact.enabled }}
    {{- if eq (include "collectors.hasExtraPort" (dict "collectorValues" $collectorValues "portNumber" $.Values.applicationObservability.receivers.jaeger.thriftCompact.port)) "false" }}
      {{- $extraPorts = append $extraPorts (dict "name" "jaeger-compact" "port" $.Values.applicationObservability.receivers.jaeger.thriftCompact.port "targetPort" $.Values.applicationObservability.receivers.jaeger.thriftCompact.port "protocol" "UDP") }}
    {{- end -}}
  {{- end -}}
  {{- if $.Values.applicationObservability.receivers.jaeger.thriftHttp.enabled }}
    {{- if eq (include "collectors.hasExtraPort" (dict "collectorValues" $collectorValues "portNumber" $.Values.applicationObservability.receivers.jaeger.thriftHttp.port)) "false" }}
      {{- $extraPorts = append $extraPorts (dict "name" "jaeger-http" "port" $.Values.applicationObservability.receivers.jaeger.thriftHttp.port "targetPort" $.Values.applicationObservability.receivers.jaeger.thriftHttp.port "protocol" "TCP" "appProtocol" "http") }}
    {{- end -}}
  {{- end -}}

  {{- $values = $values | merge (dict "collectors" (dict $collectorName (dict "alloy" (dict "extraPorts" $extraPorts)))) }}
  {{- $values | toYaml }}
{{- end -}}
{{- end -}}

{{- define "features.applicationObservability.validate" }}
{{- if .Values.applicationObservability.enabled -}}
  {{- $featureKey := "applicationObservability" }}
  {{- $featureName := "Application Observability" }}

  {{/* Destination validations */}}
  {{- if .Values.applicationObservability.metrics.enabled -}}
    {{- $metricDestinations := include "destinations.get" (dict "destinations" $.Values.destinations "type" "metrics" "ecosystem" "otlp" "filter" $.Values.applicationObservability.destinations) | fromYamlArray -}}
    {{- include "destinations.validate.destinationListNotEmpty" (dict "destinations" $metricDestinations "type" "metrics" "ecosystem" "otlp" "featureName" $featureName "Values" $.Values "featureKey" $featureKey) }}
    {{- include "dataProcessors.validate.feature" (dict "root" $ "featureKey" $featureKey "featureName" $featureName "type" "metrics" "ecosystem" "otlp") }}
  {{- end -}}

  {{- if .Values.applicationObservability.logs.enabled -}}
    {{- $logDestinations := include "destinations.get" (dict "destinations" $.Values.destinations "type" "logs" "ecosystem" "otlp" "filter" $.Values.applicationObservability.destinations) | fromYamlArray -}}
    {{- include "destinations.validate.destinationListNotEmpty" (dict "destinations" $logDestinations "type" "logs" "ecosystem" "otlp" "featureName" $featureName "Values" $.Values "featureKey" $featureKey) }}
    {{- include "dataProcessors.validate.feature" (dict "root" $ "featureKey" $featureKey "featureName" $featureName "type" "logs" "ecosystem" "otlp") }}
  {{- end -}}

  {{- if .Values.applicationObservability.traces.enabled -}}
    {{- $traceDestinations := include "destinations.get" (dict "destinations" $.Values.destinations "type" "traces" "ecosystem" "otlp" "filter" $.Values.applicationObservability.destinations) | fromYamlArray -}}
    {{- include "destinations.validate.destinationListNotEmpty" (dict "destinations" $traceDestinations "type" "traces" "ecosystem" "otlp" "featureName" $featureName "Values" $.Values "featureKey" $featureKey) }}
    {{- include "dataProcessors.validate.feature" (dict "root" $ "featureKey" $featureKey "featureName" $featureName "type" "traces" "ecosystem" "otlp") }}
  {{- end -}}

  {{/* Collector validations */}}
  {{- $collectorName := include "collectors.getCollectorForFeature" (dict "Values" $.Values "featureKey" $featureKey) }}
  {{- $collectorValues := (include "collector.alloy.values" (dict "Values" $.Values "Files" $.Files "collectorName" $collectorName) | fromYaml) }}
  {{- include "collectors.validate.collectorIsAssigned" (dict "Values" $.Values "collectorName" $collectorName "featureKey" $featureKey "featureName" $featureName) }}
  {{- if $.Values.applicationObservability.receivers.otlp.grpc.enabled }}
    {{- include "collectors.requireExtraPort" (dict "collectorName" $collectorName "collectorValues" $collectorValues "featureName" $featureName "portNumber" $.Values.applicationObservability.receivers.otlp.grpc.port "portName" "otlp-grpc" "portProtocol" "TCP") }}
  {{- end -}}
  {{- if $.Values.applicationObservability.receivers.otlp.http.enabled }}
    {{- include "collectors.requireExtraPort" (dict "collectorName" $collectorName "collectorValues" $collectorValues "featureName" $featureName "portNumber" $.Values.applicationObservability.receivers.otlp.http.port "portName" "otlp-http" "portProtocol" "TCP") }}
  {{- end -}}
  {{- if $.Values.applicationObservability.receivers.zipkin.enabled }}
    {{- include "collectors.requireExtraPort" (dict "collectorName" $collectorName "collectorValues" $collectorValues "featureName" $featureName "portNumber" $.Values.applicationObservability.receivers.zipkin.port "portName" "zipkin" "portProtocol" "TCP") }}
  {{- end -}}
  {{- if $.Values.applicationObservability.receivers.jaeger.grpc.enabled }}
    {{- include "collectors.requireExtraPort" (dict "collectorName" $collectorName "collectorValues" $collectorValues "featureName" $featureName "portNumber" $.Values.applicationObservability.receivers.jaeger.grpc.port "portName" "jaeger-grpc" "portProtocol" "TCP") }}
  {{- end -}}
  {{- if $.Values.applicationObservability.receivers.jaeger.thriftBinary.enabled }}
    {{- include "collectors.requireExtraPort" (dict "collectorName" $collectorName "collectorValues" $collectorValues "featureName" $featureName "portNumber" $.Values.applicationObservability.receivers.jaeger.thriftBinary.port "portName" "jaeger-binary" "portProtocol" "UDP") }}
  {{- end -}}
  {{- if $.Values.applicationObservability.receivers.jaeger.thriftCompact.enabled }}
    {{- include "collectors.requireExtraPort" (dict "collectorName" $collectorName "collectorValues" $collectorValues "featureName" $featureName "portNumber" $.Values.applicationObservability.receivers.jaeger.thriftCompact.port "portName" "jaeger-compact" "portProtocol" "UDP") }}
  {{- end -}}
  {{- if $.Values.applicationObservability.receivers.jaeger.thriftHttp.enabled }}
    {{- include "collectors.requireExtraPort" (dict "collectorName" $collectorName "collectorValues" $collectorValues "featureName" $featureName "portNumber" $.Values.applicationObservability.receivers.jaeger.thriftHttp.port "portName" "jaeger-http" "portProtocol" "TCP") }}
  {{- end -}}
  {{- include "feature.applicationObservability.validate" (dict "Values" $.Values.applicationObservability) }}
  {{- end -}}
{{- end -}}

{{- define "features.applicationObservability.receiver.grpc" }}
{{- $featureKey := "applicationObservability" }}
{{- if and .Values.applicationObservability.enabled .Values.applicationObservability.receivers.otlp.grpc.enabled }}
  {{- $collectorName := include "collectors.getCollectorForFeature" (dict "Values" $.Values "featureKey" $featureKey) }}
  {{- $values := dict "Values" $.Values "Chart" $.Chart "Release" $.Release "collectorName" $collectorName }}
http://{{ include "collector.alloy.fullname" $values }}.{{ include "helper.namespace" . }}.svc.cluster.local:{{ .Values.applicationObservability.receivers.otlp.grpc.port }}
{{- end }}
{{- end }}

{{- define "features.applicationObservability.receiver.http" }}
{{- $featureKey := "applicationObservability" }}
{{- if and .Values.applicationObservability.enabled .Values.applicationObservability.receivers.otlp.http.enabled }}
  {{- $collectorName := include "collectors.getCollectorForFeature" (dict "Values" $.Values "featureKey" $featureKey) }}
  {{- $values := dict "Values" $.Values "Chart" $.Chart "Release" $.Release "collectorName" $collectorName }}
http://{{ include "collector.alloy.fullname" $values }}.{{ include "helper.namespace" . }}.svc.cluster.local:{{ .Values.applicationObservability.receivers.otlp.http.port }}
{{- end }}
{{- end }}
