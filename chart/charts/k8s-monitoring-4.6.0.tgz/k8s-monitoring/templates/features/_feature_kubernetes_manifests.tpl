{{- define "features.kubernetesManifests.enabled" }}{{ .Values.kubernetesManifests.enabled }}{{- end }}

{{- define "features.kubernetesManifests.include" }}
{{- if .Values.kubernetesManifests.enabled -}}
{{- $destinations := include "features.kubernetesManifests.destinations" . | fromYamlArray }}
// Feature: Kubernetes Manifests
{{- include "feature.kubernetesManifests.module" (dict "Values" $.Values.kubernetesManifests "Files" $.Subcharts.kubernetesManifests.Files "Release" $.Release "telemetryServices" $.Values.telemetryServices) }}
kubernetes_manifests "feature" {
  logs_destinations = [
    {{ include "dataProcessors.pipeline.targets.forFeature" (dict "root" $ "featureKey" "kubernetesManifests" "destinationNames" $destinations "type" "logs" "ecosystem" "loki") | indent 4 | trim }}
  ]
}
{{- include "dataProcessors.pipeline.render.forFeature" (dict "root" $ "featureKey" "kubernetesManifests" "destinationNames" $destinations "type" "logs" "ecosystem" "loki") }}
{{- end -}}
{{- end -}}

{{- define "features.kubernetesManifests.destinations" }}
{{- if .Values.kubernetesManifests.enabled -}}
  {{- include "destinations.get" (dict "destinations" $.Values.destinations "type" "logs" "ecosystem" "loki" "filter" $.Values.kubernetesManifests.destinations) -}}
{{- end -}}
{{- end -}}

{{- define "features.kubernetesManifests.destinations.isTranslating" }}
{{- $isTranslating := false -}}
{{- $destinations := include "features.kubernetesManifests.destinations" . | fromYamlArray -}}
{{ range $destination := $destinations -}}
  {{- $destinationEcosystem := include "destination.getEcosystem" (deepCopy $ | merge (dict "destination" $destination)) -}}
  {{- if ne $destinationEcosystem "loki" -}}
    {{- $isTranslating = true -}}
  {{- end -}}
{{- end -}}
{{- $isTranslating -}}
{{- end -}}

{{- define "features.kubernetesManifests.collector.values" }}{{- end -}}

{{- define "features.kubernetesManifests.validate" }}
{{- if .Values.kubernetesManifests.enabled -}}
{{- $featureKey := "kubernetesManifests" }}
{{- $featureName := "Kubernetes Manifests" }}
{{- $destinationNames := include "features.kubernetesManifests.destinations" . | fromYamlArray }}
{{- include "destinations.validate.destinationListNotEmpty" (dict "destinations" $destinationNames "type" "logs" "ecosystem" "loki" "featureName" $featureName "Values" $.Values "featureKey" $featureKey) }}
{{- include "dataProcessors.validate.feature" (dict "root" $ "featureKey" "kubernetesManifests" "featureName" $featureName "type" "logs" "ecosystem" "loki") }}
{{- $collectorName := include "collectors.getCollectorForFeature" (dict "Values" $.Values "featureKey" $featureKey) }}
{{- include "collectors.validate.collectorIsAssigned" (dict "Values" $.Values "collectorName" $collectorName "featureKey" $featureKey "featureName" $featureName) }}
{{- $k8sManifestTail := index $.Values.telemetryServices "k8s-manifest-tail" }}
{{- if not (dig "deploy" false $k8sManifestTail) }}
  {{- $msg := list "" (printf "The %s feature requires k8s-manifest-tail to be deployed." $featureName) }}
  {{- $msg = append $msg "Please set:" }}
  {{- $msg = append $msg "telemetryServices:" }}
  {{- $msg = append $msg "  k8s-manifest-tail:" }}
  {{- $msg = append $msg "    deploy: true" }}
  {{- fail (join "\n" $msg) }}
{{- end }}
{{- end -}}
{{- end -}}
