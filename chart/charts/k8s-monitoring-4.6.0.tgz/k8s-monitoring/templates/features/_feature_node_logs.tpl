{{- define "features.nodeLogs.enabled" }}{{ .Values.nodeLogs.enabled }}{{- end }}

{{- define "features.nodeLogs.include" }}
{{- if .Values.nodeLogs.enabled -}}
{{- $destinations := include "features.nodeLogs.destinations" . | fromYamlArray }}

// Feature: Node Logs
{{- include "feature.nodeLogs.module" (dict "Values" .Values.nodeLogs "Files" $.Subcharts.nodeLogs.Files "Template" $.Template) }}
node_logs "feature" {
  logs_destinations = [
    {{ include "dataProcessors.pipeline.targets.forFeature" (dict "root" $ "featureKey" "nodeLogs" "destinationNames" $destinations "type" "logs" "ecosystem" "loki") | indent 4 | trim }}
  ]
}
{{- include "dataProcessors.pipeline.render.forFeature" (dict "root" $ "featureKey" "nodeLogs" "destinationNames" $destinations "type" "logs" "ecosystem" "loki") }}
{{- end -}}
{{- end -}}

{{- define "features.nodeLogs.destinations" }}
{{- if .Values.nodeLogs.enabled -}}
{{- include "destinations.get" (dict "destinations" $.Values.destinations "type" "logs" "ecosystem" "loki" "filter" $.Values.nodeLogs.destinations) -}}
{{- end -}}
{{- end -}}

{{- define "features.nodeLogs.destinations.isTranslating" }}
{{- $isTranslating := false -}}
{{- $destinations := include "features.nodeLogs.destinations" . | fromYamlArray -}}
{{ range $destination := $destinations -}}
  {{- $destinationEcosystem := include "destination.getEcosystem" (deepCopy $ | merge (dict "destination" $destination)) -}}
  {{- if ne $destinationEcosystem "loki" -}}
    {{- $isTranslating = true -}}
  {{- end -}}
{{- end -}}
{{- $isTranslating -}}
{{- end -}}

{{- define "features.nodeLogs.collector.values" }}{{- end -}}

{{- define "features.nodeLogs.validate" }}
{{- if .Values.nodeLogs.enabled -}}
{{- $featureKey := "nodeLogs" }}
{{- $featureName := "Kubernetes Node logs" }}
{{- $destinations := include "features.nodeLogs.destinations" . | fromYamlArray }}
{{- include "destinations.validate.destinationListNotEmpty" (dict "destinations" $destinations "type" "logs" "ecosystem" "loki" "featureName" $featureName "Values" $.Values "featureKey" $featureKey) }}
{{- include "dataProcessors.validate.feature" (dict "root" $ "featureKey" "nodeLogs" "featureName" $featureName "type" "logs" "ecosystem" "loki") }}

{{- $collectorName := include "collectors.getCollectorForFeature" (dict "Values" $.Values "featureKey" $featureKey) }}
{{- include "collectors.validate.collectorIsAssigned" (dict "Values" $.Values "collectorName" $collectorName "featureKey" $featureKey "featureName" $featureName) }}
{{- $collectorValues := include "collector.alloy.values" (dict "Values" $.Values "Files" $.Files "collectorName" $collectorName) | fromYaml }}
{{- include "feature.nodeLogs.collector.validate" (dict "Values" $.Values.nodeLogs "Collector" $collectorValues "CollectorName" $collectorName) }}
{{- end -}}
{{- end -}}
